const canvas = document.querySelector("#mapCanvas");
const ctx = canvas.getContext("2d");
const viewport = document.querySelector(".viewport");
const mainMenuOverlay = document.querySelector("#mainMenuOverlay");
const playInspector = document.querySelector("#playInspector");
const unitActionBar = document.querySelector("#unitActionBar");
const gameActionMenu = document.querySelector("#gameActionMenu");
const saveSlotOverlay = document.querySelector("#saveSlotOverlay");
const saveSlotPanel = document.querySelector("#saveSlotPanel");
const saveSlotTitle = document.querySelector("#saveSlotTitle");
const saveSlotInput = document.querySelector("#saveSlotInput");
const saveSlotList = document.querySelector("#saveSlotList");
const saveSlotEmpty = document.querySelector("#saveSlotEmpty");
const appTitleElements = [...document.querySelectorAll('[data-role="app-title"]')];
const appSubtitleElements = [...document.querySelectorAll('[data-role="app-subtitle"]')];
const inspectorTitleElements = [...document.querySelectorAll('[data-role="inspector-title"]')];
const topBars = {
  menu: document.querySelector('[data-bar-mode="menu"]'),
  play: document.querySelector('[data-bar-mode="play"]'),
  edit: document.querySelector('[data-bar-mode="edit"]'),
};
const hoverReadouts = [...document.querySelectorAll('[data-role="hover-readout"]')];
const mapSizeReadouts = [...document.querySelectorAll('[data-role="map-size"]')];
const tileMenu = document.querySelector("#tileMenu");
const tileMenuTitle = document.querySelector("#tileMenuTitle");
const variantMenuTitle = document.querySelector("#variantMenuTitle");
const terrainMenuOptions = document.querySelector("#terrainMenuOptions");
const variantMenu = document.querySelector("#variantMenu");
const variantMenuOptions = document.querySelector("#variantMenuOptions");
const zoomControlGroups = [...document.querySelectorAll(".zoom-controls")];
const gameMenuToggleButtons = [...document.querySelectorAll('[data-action="toggle-game-menu"]')];
const newRandomMapButtons = [...document.querySelectorAll('[data-action="new-random-map"]')];
const newEmptyMapButtons = [...document.querySelectorAll('[data-action="new-empty-map"]')];
const loadStateButtons = [...document.querySelectorAll('[data-action="load-state"]')];
const saveStateButtons = [...document.querySelectorAll('[data-action="save-state"]')];
const saveStateAsButtons = [...document.querySelectorAll('[data-action="save-state-as"]')];
const openMainMenuButtons = [...document.querySelectorAll('[data-action="main-menu"]')];
const dismissSlotPanelButtons = [...document.querySelectorAll('[data-action="close-slot-panel"], [data-action="cancel-slot-panel"]')];
const cancelSlotPanelButtons = [...document.querySelectorAll('[data-action="cancel-slot-panel"]')];
const closeSlotPanelIconButtons = [...document.querySelectorAll('[data-action="close-slot-panel"]')];
const confirmSlotPanelButtons = [...document.querySelectorAll('[data-action="confirm-slot-panel"]')];
const importSlotPanelButtons = [...document.querySelectorAll('[data-action="import-slot-panel"]')];
const zoomOutButtons = [...document.querySelectorAll('[data-action="zoom-out"]')];
const zoomInButtons = [...document.querySelectorAll('[data-action="zoom-in"]')];
const zoomLevelReadouts = [...document.querySelectorAll('[data-role="zoom-level"]')];
const unitReadouts = [...document.querySelectorAll('[data-role="unit-readout"]')];
const turnReadouts = [...document.querySelectorAll('[data-role="turn-readout"]')];
const fileReadouts = [...document.querySelectorAll('[data-role="file-readout"]')];
const nextTurnButtons = [...document.querySelectorAll('[data-action="next-turn"]')];
const autoPassInputs = [...document.querySelectorAll('[data-action="auto-pass"]')];
const unitActionButtons = [...document.querySelectorAll('[data-action="select-unit-action"]')];
const autoPassLabels = [...document.querySelectorAll('[data-role="auto-pass-label"]')];
const slotNameLabels = [...document.querySelectorAll('[data-role="slot-name-label"]')];
const slotListTitles = [...document.querySelectorAll('[data-role="slot-list-title"]')];
const mainMenuItems = {
  watchIntro: mainMenuOverlay.querySelector('.main-menu-item[data-menu-action="watch-intro"]'),
  startNewGame: mainMenuOverlay.querySelector('.main-menu-item[data-menu-action="start-new-game"]'),
  play: mainMenuOverlay.querySelector('.main-menu-item[data-menu-action="play"]'),
  loadGame: mainMenuOverlay.querySelector('.main-menu-item[data-menu-action="load-game"]'),
  edit: mainMenuOverlay.querySelector('.main-menu-item[data-menu-action="edit"]'),
  importExport: mainMenuOverlay.querySelector('.main-menu-item[data-menu-action="import-export"]'),
};
const staticLayerCanvas = document.createElement("canvas");
const staticLayerCtx = staticLayerCanvas.getContext("2d");
const staticUnitsLayerCanvases = [document.createElement("canvas"), document.createElement("canvas")];
const staticUnitsLayerContexts = staticUnitsLayerCanvases.map((layerCanvas) => layerCanvas.getContext("2d"));

const rules = window.APP_RULES;
const localization = window.APP_LOCALIZATION;
const currentLanguage = localization?.defaultLanguage || "en";
const strings = localization?.languages?.[currentLanguage];

if (!rules) {
  throw new Error("Missing game rules.");
}

if (!strings) {
  throw new Error(`Missing localization strings for language: ${currentLanguage}`);
}

const canvasPadding = 64;

const baseTile = {
  width: 88,
  height: 44,
  edge: 12,
};

const tile = { ...baseTile };

const zoomLevels = [0.5, 1, 2];
const interactionModes = {
  edit: "edit",
  play: "play",
};
const unitActions = {
  wait: "wait",
  walk: "walk",
  play: "play",
  buildHouse: "buildHouse",
  demolish: "demolish",
};
const unitSprite = {
  idleImage: "assets/units/unit_sprite.png",
  northImage: "assets/units/unit_back_sprite.png",
  southImage: "assets/units/unit_front_sprite.png",
  workFrames: [
    "assets/units/unit_work_sprite.png",
    "assets/units/unit_work_sprite_1.png",
  ],
  playFrames: [
    "assets/units/unit_play_sprite.png",
    "assets/units/unit_play_sprite_1.png",
  ],
  workFrameDuration: 180,
  northMoveFrames: [
    "assets/units/unit_back_step_sprite.png",
    "assets/units/unit_back_step_sprite_2.png",
  ],
  southMoveFrames: [
    "assets/units/unit_front_step_sprite.png",
    "assets/units/unit_front_step_sprite_2.png",
  ],
  moveFrames: ["assets/units/unit_sprite.png", "assets/units/unit_step_sprite.png"],
  moveFrameSequence: [0, 1, 0, 1, 0, 1, 0, 1, 0],
  width: 36,
  height: 44,
  anchorX: 18,
  anchorY: 44,
  groundOffset: 0.75,
  moveDuration: 720,
};

const map = {
  width: 42,
  height: 64,
  cells: [],
};
const defaultMapConfig = {
  width: map.width,
  height: map.height,
};

const terrain = {
  water: {
    label: strings.terrain.water,
    image: "assets/tiles/water_01.png",
    variants: [
      {
        id: "water_01",
        label: strings.terrainVariants.water_01,
        image: "assets/tiles/water_01.png",
        weight: 1,
      },
      {
        id: "water_02",
        label: strings.terrainVariants.water_02,
        image: "assets/tiles/water_02.png",
        weight: 9,
      },
    ],
    top: "#3d8bb4",
    side: "#27627f",
    detail: "#b7dcec",
    stroke: "#23536b",
  },
  grass: {
    label: strings.terrain.grass,
    image: "assets/tiles/grass_01.png",
    variants: [
      { id: "grass_01", label: strings.terrainVariants.grass_01, image: "assets/tiles/grass_01.png" },
      { id: "grass_02", label: strings.terrainVariants.grass_02, image: "assets/tiles/grass_02.png" },
    ],
    top: "#77a85b",
    side: "#4e7a42",
    detail: "#cae386",
    stroke: "#426b39",
  },
  forest: {
    label: strings.terrain.forest,
    image: "assets/tiles/forest_01.png",
    variants: [
      {
        id: "forest_01",
        label: strings.terrainVariants.forest_01,
        image: "assets/tiles/forest_01.png",
      },
      {
        id: "forest_02",
        label: strings.terrainVariants.forest_02,
        image: "assets/tiles/forest_02.png",
      },
    ],
    top: "#4d8a54",
    side: "#315f3c",
    detail: "#1f4f32",
    stroke: "#2d5435",
  },
  mountain: {
    label: strings.terrain.mountain,
    image: "assets/tiles/hill_01.png",
    variants: [
      {
        id: "mountain_01",
        label: strings.terrainVariants.mountain_01,
        image: "assets/tiles/hill_01.png",
        weight: 1,
      },
      {
        id: "mountain_02",
        label: strings.terrainVariants.mountain_02,
        image: "assets/tiles/hill_02.png",
        weight: 9,
      },
    ],
    top: "#a79569",
    side: "#7b684d",
    detail: "#e0d2a1",
    stroke: "#68583f",
  },
};

const buildingCatalog = {
  house: {
    subtypes: [
      { id: "house_01", image: "assets/buildings/house_01.png" },
      { id: "house_02", image: "assets/buildings/house_02.png" },
      { id: "house_03", image: "assets/buildings/house_03.png" },
      { id: "house_04", image: "assets/buildings/house_04.png" },
    ],
    abandonedImage: "assets/buildings/house_abandoned.png",
    constructionImages: {
      initial: "assets/buildings/house_construct.png",
      half: "assets/buildings/house_half.png",
    },
  },
};

const transitionRules = [
  {
    baseType: "water",
    neighborTypes: ["grass", "forest", "mountain"],
    drawEdge: drawShoreEdge,
    drawCorner: drawShoreCorner,
  },
];

const shoreOverlays = {
  edge: {
    northWest: "assets/tiles/shore/shore_edge_nw.png",
    northEast: "assets/tiles/shore/shore_edge_ne.png",
    southEast: "assets/tiles/shore/shore_edge_se.png",
    southWest: "assets/tiles/shore/shore_edge_sw.png",
  },
  corner: {
    north: "assets/tiles/shore/shore_corner_n.png",
    east: "assets/tiles/shore/shore_corner_e.png",
    south: "assets/tiles/shore/shore_corner_s.png",
    west: "assets/tiles/shore/shore_corner_w.png",
  },
};

// Visual transitions are derived from neighbors; they are not stored in map.cells.
let origin = { x: 0, y: 0 };
let hoverCell = null;
let activeCell = null;
let drawList = [];
let didCenterInitialView = false;
let zoomIndex = 1;
let interactionMode = null;
let mainMenuOpen = true;
let units = [];
let unit = null;
let buildings = [];
let animationFrameId = 0;
let staticLayerDirty = true;
let staticUnitsLayerDirty = true;
let currentDpr = 1;
let currentTurn = 1;
let autoAdvanceTurns = true;
let autoAdvanceQueued = false;
let autoAdvanceFrameId = 0;
let turnResolutionPauseTimeoutId = 0;
let turnResolutionActive = false;
let turnResolutionHadAnimation = false;
let turnResolutionHadWork = false;
let selectedUnitAction = unitActions.walk;
let activeGameMenuButton = null;
let slotPanelState = null;
const tileImages = {};
const buildingImages = {};
const shoreOverlayImages = {};
const unitImages = {};
const saveVersion = 4;
const storageKeys = {
  filePrefix: "schtroumpfilization:save-file:v1:",
  currentFile: {
    edit: "schtroumpfilization:current-file:edit:v1",
    play: "schtroumpfilization:current-file:play:v1",
  },
};
const currentFileNames = {
  edit: null,
  play: null,
};
const autosaveSlotName = "autosave";
const workTurnDisplayDelayMs = 720;

function setTextContent(elements, text) {
  for (const element of elements) {
    element.textContent = text;
  }
}

function setDisabledState(elements, disabled) {
  for (const element of elements) {
    element.disabled = disabled;
  }
}

function setCheckedState(elements, checked) {
  for (const element of elements) {
    element.checked = checked;
  }
}

function setAttributeForElements(elements, name, value) {
  for (const element of elements) {
    element.setAttribute(name, value);
  }
}

function clearQueuedAutoAdvanceFrame() {
  if (autoAdvanceFrameId) {
    cancelAnimationFrame(autoAdvanceFrameId);
    autoAdvanceFrameId = 0;
  }

  autoAdvanceQueued = false;
}

function clearPendingAutoAdvance() {
  clearQueuedAutoAdvanceFrame();

  if (turnResolutionPauseTimeoutId) {
    window.clearTimeout(turnResolutionPauseTimeoutId);
    turnResolutionPauseTimeoutId = 0;
  }
}

function normalizeUnitAction(action) {
  return Object.values(unitActions).includes(action) ? action : unitActions.walk;
}

function getUnitActionLabel(action) {
  if (action === unitActions.wait) {
    return strings.actions.wait;
  }

  if (action === unitActions.play) {
    return strings.actions.play;
  }

  if (action === unitActions.buildHouse) {
    return strings.actions.buildHouse;
  }

  if (action === unitActions.demolish) {
    return strings.actions.demolish;
  }

  return strings.actions.walk;
}

function applyStaticText() {
  document.documentElement.lang = currentLanguage;
  document.title = strings.app.title;
  viewport.setAttribute("aria-label", strings.aria.viewport);
  terrainMenuOptions.setAttribute("aria-label", strings.aria.terrainMenu);
  variantMenuOptions.setAttribute("aria-label", strings.aria.variantMenu);
  gameActionMenu?.setAttribute("aria-label", strings.aria.gameMenu);
  saveSlotPanel?.setAttribute("aria-label", strings.aria.saveSlots);
  mainMenuOverlay?.setAttribute("aria-label", strings.aria.mainMenu);
  unitActionBar?.setAttribute("aria-label", strings.aria.unitActions);
  setTextContent(appTitleElements, strings.app.title);
  setTextContent(inspectorTitleElements, strings.play.inspectorTitle);
  setTextContent(gameMenuToggleButtons, strings.actions.menu);
  setTextContent(newRandomMapButtons, strings.actions.newRandomMap);
  setTextContent(newEmptyMapButtons, strings.actions.newEmptyMap);
  setTextContent(loadStateButtons, strings.actions.load);
  setTextContent(saveStateButtons, strings.actions.save);
  setTextContent(saveStateAsButtons, strings.actions.saveAs);
  setTextContent(openMainMenuButtons, strings.actions.mainMenu);
  setTextContent(nextTurnButtons, strings.actions.nextTurn);
  setTextContent(autoPassLabels, strings.toggles.autoPass);
  setTextContent(slotNameLabels, strings.saveSlots.slotName);
  setTextContent(slotListTitles, strings.saveSlots.existingSlots);
  setTextContent(confirmSlotPanelButtons, strings.actions.save);
  setTextContent(importSlotPanelButtons, strings.actions.importFile);
  setTextContent(cancelSlotPanelButtons, strings.actions.cancel);
  setAttributeForElements(closeSlotPanelIconButtons, "aria-label", strings.actions.close);
  if (saveSlotEmpty) {
    saveSlotEmpty.textContent = strings.saveSlots.empty;
  }
  setTextContent([mainMenuItems.watchIntro], strings.menu.watchIntro);
  setTextContent([mainMenuItems.startNewGame], strings.menu.startNewGame);
  setTextContent([mainMenuItems.play], strings.menu.play);
  setTextContent([mainMenuItems.loadGame], strings.menu.loadGame);
  setTextContent([mainMenuItems.edit], strings.menu.edit);
  setTextContent([mainMenuItems.importExport], strings.menu.importExport);
  setTextContent([variantMenuTitle], strings.menu.visual);
  setAttributeForElements(zoomControlGroups, "aria-label", strings.aria.zoomControls);
  setAttributeForElements(zoomOutButtons, "aria-label", strings.aria.zoomOut);
  setAttributeForElements(zoomInButtons, "aria-label", strings.aria.zoomIn);

  for (const button of unitActionButtons) {
    const action = normalizeUnitAction(button.dataset.unitAction);
    const label = getUnitActionLabel(action);

    button.setAttribute("aria-label", label);
    button.title = label;
  }
}

function sanitizeFileName(fileName) {
  if (typeof fileName !== "string") return "";
  return fileName.trim();
}

function getCurrentFileKey(mode) {
  return storageKeys.currentFile[mode] || null;
}

function getSaveFileKey(fileName) {
  const normalizedName = sanitizeFileName(fileName);

  if (!normalizedName) return null;
  return `${storageKeys.filePrefix}${encodeURIComponent(normalizedName)}`;
}

function readCurrentFileName(mode) {
  if (currentFileNames[mode]) return currentFileNames[mode];

  const storageKey = getCurrentFileKey(mode);

  if (!storageKey) return null;

  try {
    const fileName = sanitizeFileName(window.localStorage.getItem(storageKey) || "");
    currentFileNames[mode] = fileName || null;
    return currentFileNames[mode];
  } catch (error) {
    console.warn(`Could not read current file name for ${mode}.`, error);
    return null;
  }
}

function writeCurrentFileName(mode, fileName) {
  const storageKey = getCurrentFileKey(mode);
  const normalizedName = sanitizeFileName(fileName);

  currentFileNames[mode] = normalizedName || null;

  if (!storageKey) return;

  try {
    if (normalizedName) {
      window.localStorage.setItem(storageKey, normalizedName);
    } else {
      window.localStorage.removeItem(storageKey);
    }
  } catch (error) {
    console.warn(`Could not write current file name for ${mode}.`, error);
  }
}

function getCurrentFileName(mode = interactionMode) {
  return mode ? readCurrentFileName(mode) : null;
}

function updateFileReadout() {
  const fileName = getCurrentFileName();

  setTextContent(
    fileReadouts,
    fileName ? strings.readouts.file(fileName) : strings.readouts.fileNone,
  );
}

function getAppSubtitleText() {
  if (mainMenuOpen || !interactionMode) return "";
  if (interactionMode === interactionModes.edit) return strings.app.editorSubtitle;
  return "";
}

function updatePersistenceControls() {
  const disabled =
    !interactionMode ||
    turnResolutionActive ||
    getUnits().some((currentUnit) => isUnitAnimating(currentUnit));

  setDisabledState(loadStateButtons, disabled);
  setDisabledState(saveStateButtons, disabled);
  setDisabledState(saveStateAsButtons, disabled);
  updateFileReadout();
}

function getDefaultUnitStamina() {
  return Math.max(1, clampInteger(rules.units?.default?.stamina, 1, 999, 2));
}

function getDefaultUnitName() {
  const configured = typeof rules.units?.default?.name === "string" ? rules.units.default.name.trim() : "";
  return configured || "Schtroumpf";
}

function normalizeUnitName(name) {
  const normalized = typeof name === "string" ? name.trim() : "";
  return normalized || getDefaultUnitName();
}

function getUnitHomeBuildingId(currentUnit) {
  return typeof currentUnit?.homeBuildingId === "string" && currentUnit.homeBuildingId
    ? currentUnit.homeBuildingId
    : null;
}

function getUnitMaxStamina(currentUnit = unit) {
  return Math.max(1, clampInteger(currentUnit?.staminaMax, 1, 999, getDefaultUnitStamina()));
}

function getUnitStamina(currentUnit = unit) {
  return Math.max(0, clampInteger(currentUnit?.stamina, 0, 999, getUnitMaxStamina(currentUnit)));
}

function getTerrainMoveCost(cell) {
  if (!cell) return Number.POSITIVE_INFINITY;

  const configuredCost = rules.movement?.terrainCost?.[cell.type];

  if (!Number.isFinite(configuredCost)) {
    return Number.POSITIVE_INFINITY;
  }

  return Math.max(1, configuredCost);
}

function getUnitWorkPointsPerTurn(taskType) {
  const configured = Number(rules.units?.default?.workPointsPerTurn?.[taskType]);

  if (!Number.isFinite(configured)) {
    return 0;
  }

  return Math.max(0, configured);
}

function getSelectedUnit() {
  return units.find((currentUnit) => currentUnit?.selected) || null;
}

function syncActiveUnit(preferredUnitId = unit?.id || null) {
  const selectedUnit = getSelectedUnit();

  if (selectedUnit) {
    unit = selectedUnit;
    return unit;
  }

  if (preferredUnitId) {
    const preferredUnit = units.find((currentUnit) => currentUnit?.id === preferredUnitId) || null;

    if (preferredUnit) {
      unit = preferredUnit;
      return unit;
    }
  }

  unit = units[0] || null;
  return unit;
}

function getUnitById(unitId) {
  return units.find((currentUnit) => currentUnit?.id === unitId) || null;
}

function createUnitId(items = units) {
  let maxIndex = 0;

  for (const currentUnit of items) {
    const match = /^unit_(\d+)$/.exec(currentUnit?.id || "");

    if (!match) continue;
    maxIndex = Math.max(maxIndex, Number.parseInt(match[1], 10) || 0);
  }

  return `unit_${String(maxIndex + 1).padStart(2, "0")}`;
}

function getBuildingRules(type) {
  return rules.buildings?.[type] || null;
}

function getBuildingSpec(type) {
  return buildingCatalog[type] || null;
}

function getBuildingSubtypeVariants(type) {
  return getBuildingSpec(type)?.subtypes || [];
}

function chooseBuildingSubtype(type) {
  const variants = getBuildingSubtypeVariants(type);

  if (variants.length === 0) return null;

  const index = Math.floor(Math.random() * variants.length);
  return variants[index].id;
}

function getDefaultBuildingWidth() {
  return Math.max(1, clampInteger(rules.buildings?.default?.width, 1, 16, 1));
}

function getDefaultBuildingHeight() {
  return Math.max(1, clampInteger(rules.buildings?.default?.height, 1, 16, 1));
}

function getBuildingCompleteness(building) {
  const completeness = Number(building?.completeness);

  if (!Number.isFinite(completeness)) {
    return 1;
  }

  return clamp(completeness, 0, 1);
}

function getBuildingConstructionCost(type) {
  return Math.max(1, clampInteger(getBuildingRules(type)?.constructionCost, 1, 999999, 100));
}

function isBuildingWalkable(type) {
  return Boolean(getBuildingRules(type)?.walkable);
}

function getBuildingAbandonedDecay(type) {
  const decay = Number(getBuildingRules(type)?.abandonedDecayPerTurn);

  if (!Number.isFinite(decay)) {
    return 0;
  }

  return clamp(decay, 0, 1);
}

function getBuildingConstructionThresholds(type) {
  const thresholds = getBuildingRules(type)?.constructionVisualThresholds || {};
  const initialValue = Number(thresholds.initialMax);
  const halfValue = Number(thresholds.halfMax);
  const initialMax = Number.isFinite(initialValue) ? clamp(initialValue, 0, 1) : 0.34;
  const halfMax = Number.isFinite(halfValue) ? clamp(halfValue, initialMax, 1) : 0.79;

  return {
    initialMax,
    halfMax,
  };
}

function getBuildingWorkCompletenessDelta(taskType, buildingType) {
  const workPoints = getUnitWorkPointsPerTurn(taskType);
  const cost = getBuildingConstructionCost(buildingType);

  if (workPoints <= 0 || cost <= 0) {
    return 0;
  }

  return clamp(workPoints / cost, 0, 1);
}

function getSaveSlotNames() {
  return getSaveSlotEntries().map((entry) => entry.name);
}

function getSaveSlotEntries() {
  const entries = [];

  try {
    for (let index = 0; index < window.localStorage.length; index += 1) {
      const key = window.localStorage.key(index);

      if (!key || !key.startsWith(storageKeys.filePrefix)) continue;

      const name = decodeURIComponent(key.slice(storageKeys.filePrefix.length));
      const raw = window.localStorage.getItem(key);
      let parsed = null;
      let isValidJson = false;

      if (typeof raw === "string") {
        try {
          parsed = JSON.parse(raw);
          isValidJson = true;
        } catch (error) {
          parsed = null;
        }
      }

      entries.push({
        name,
        raw: typeof raw === "string" ? raw : null,
        parsed,
        isValidJson,
        isCompatible: isCompatibleSaveState(parsed),
      });
    }
  } catch (error) {
    console.warn("Could not enumerate save slots.", error);
  }

  return entries.sort((a, b) => a.name.localeCompare(b.name, currentLanguage));
}

function closeGameActionMenu({ restoreFocus = false } = {}) {
  if (gameActionMenu) {
    gameActionMenu.hidden = true;
  }

  for (const button of gameMenuToggleButtons) {
    button.setAttribute("aria-expanded", "false");
  }

  if (restoreFocus && activeGameMenuButton) {
    activeGameMenuButton.focus({ preventScroll: true });
  }

  activeGameMenuButton = null;
}

function positionGameActionMenu(button) {
  if (!button || !gameActionMenu) return;

  const rect = button.getBoundingClientRect();
  const margin = 8;
  const menuWidth = gameActionMenu.offsetWidth || 180;
  const menuHeight = gameActionMenu.offsetHeight || 152;
  const left = clamp(rect.right - menuWidth, margin, window.innerWidth - menuWidth - margin);
  const top = clamp(rect.bottom + 8, margin, window.innerHeight - menuHeight - margin);

  gameActionMenu.style.left = `${left}px`;
  gameActionMenu.style.top = `${top}px`;
}

function openGameActionMenu(button) {
  if (!button || !gameActionMenu) return;

  activeGameMenuButton = button;
  gameActionMenu.hidden = false;
  positionGameActionMenu(button);

  for (const toggleButton of gameMenuToggleButtons) {
    toggleButton.setAttribute("aria-expanded", toggleButton === button ? "true" : "false");
  }

  gameActionMenu.querySelector('.game-action-item:not([hidden]):not(:disabled)')?.focus({ preventScroll: true });
}

function toggleGameActionMenu(button) {
  if (!button || !gameActionMenu) return;

  if (!gameActionMenu.hidden && activeGameMenuButton === button) {
    closeGameActionMenu({ restoreFocus: true });
    return;
  }

  openGameActionMenu(button);
}

function closeSaveSlotPanel({ restoreFocus = false } = {}) {
  if (saveSlotOverlay) {
    saveSlotOverlay.hidden = true;
  }

  if (restoreFocus && slotPanelState?.returnFocusButton) {
    slotPanelState.returnFocusButton.focus({ preventScroll: true });
  }

  slotPanelState = null;
}

function renderSaveSlotList() {
  if (!saveSlotList || !saveSlotEmpty) return;

  const saveEntries = getSaveSlotEntries();
  saveSlotList.replaceChildren();
  saveSlotEmpty.hidden = saveEntries.length > 0;

  for (const entry of saveEntries) {
    const button = document.createElement("button");
    const isSelected = slotPanelState?.value === entry.name;
    const nameSpan = document.createElement("span");
    const metaSpan = document.createElement("span");
    let metaText = "";

    button.type = "button";
    button.className = "slot-panel-item";
    nameSpan.className = "slot-panel-item-name";
    nameSpan.textContent = entry.name;
    metaSpan.className = "slot-panel-item-meta";

    if (!entry.isValidJson) {
      metaText = strings.saveSlots.invalidTag;
    } else if (!entry.isCompatible) {
      metaText = strings.saveSlots.obsoleteTag;
    }

    metaSpan.textContent = metaText;
    button.dataset.slotName = entry.name;
    button.classList.toggle("is-selected", isSelected);
    button.setAttribute("role", "option");
    button.setAttribute("aria-selected", isSelected ? "true" : "false");
    button.append(nameSpan);

    if (metaText) {
      button.append(metaSpan);
    }

    saveSlotList.append(button);
  }
}

function updateSaveSlotPanel() {
  if (!slotPanelState || !saveSlotOverlay || !saveSlotTitle || !saveSlotInput) return;

  if (slotPanelState.mode === "load") {
    saveSlotTitle.textContent = strings.saveSlots.loadTitle;
    setTextContent(confirmSlotPanelButtons, strings.actions.load);
  } else if (slotPanelState.mode === "export") {
    saveSlotTitle.textContent = strings.saveSlots.importExportTitle;
    setTextContent(confirmSlotPanelButtons, strings.actions.export);
  } else {
    saveSlotTitle.textContent = strings.saveSlots.saveAsTitle;
    setTextContent(confirmSlotPanelButtons, strings.actions.save);
  }

  for (const button of importSlotPanelButtons) {
    button.hidden = slotPanelState.mode !== "export";
  }

  saveSlotInput.value = slotPanelState.value || "";
  renderSaveSlotList();
}

function openSaveSlotPanel(mode, { targetMode = interactionMode, initialValue = null } = {}) {
  const returnFocusButton = activeGameMenuButton;
  closeGameActionMenu();

  slotPanelState = {
    mode,
    targetMode,
    value: initialValue ?? getCurrentFileName(targetMode) ?? "",
    returnFocusButton,
  };

  if (saveSlotOverlay) {
    saveSlotOverlay.hidden = false;
  }

  updateSaveSlotPanel();
  requestAnimationFrame(() => {
    saveSlotInput?.focus({ preventScroll: true });
    saveSlotInput?.select();
  });
}

async function commitSaveSlotPanel() {
  if (!slotPanelState) return false;

  const targetMode = slotPanelState.targetMode || interactionMode;

  if (!targetMode) return false;

  const fileName = sanitizeFileName(saveSlotInput?.value || slotPanelState.value || "");

  if (!fileName) {
    window.alert(strings.messages.missingSaveName);
    return false;
  }

  if (slotPanelState.mode === "load") {
    const existingState = readSaveFile(fileName);

    if (!existingState) {
      window.alert(strings.messages.saveNotFound(fileName));
      return false;
    }

    if (!isCompatibleSaveState(existingState)) {
      window.alert(strings.messages.obsoleteSave(fileName));
      return false;
    }

    if ((mainMenuOpen || interactionMode !== targetMode) && Object.values(interactionModes).includes(targetMode)) {
      setInteractionMode(targetMode);
    }

    if (!loadFileIntoMode(fileName, targetMode)) {
      window.alert(strings.messages.obsoleteSave(fileName));
      return false;
    }
  } else if (slotPanelState.mode === "export") {
    if (!(await exportSaveFile(fileName))) {
      return false;
    }
  } else {
    if (!saveStateToFile(fileName, targetMode)) {
      return false;
    }
  }

  closeSaveSlotPanel();
  return true;
}

async function requestPersistentStorage() {
  if (typeof navigator.storage?.persist !== "function") return false;

  try {
    return await navigator.storage.persist();
  } catch (error) {
    console.warn("Could not request persistent storage.", error);
    return false;
  }
}

function clampInteger(value, min, max, fallback = min) {
  const number = Number.parseInt(value, 10);

  if (!Number.isFinite(number)) return fallback;
  return clamp(number, min, max);
}

function serializeCell(cell) {
  return {
    type: cell.type,
    variant: ensureCellVariant(cell),
    visited: Boolean(cell.visited),
  };
}

function serializeBuilding(building, width = map.width, height = map.height) {
  if (!building) return null;

  return {
    id: building.id || "building_01",
    type: building.type,
    subtype: building.subtype,
    x: clampInteger(building.x, 0, width - 1, 0),
    y: clampInteger(building.y, 0, height - 1, 0),
    width: Math.max(1, clampInteger(building.width, 1, width, getDefaultBuildingWidth())),
    height: Math.max(1, clampInteger(building.height, 1, height, getDefaultBuildingHeight())),
    state: building.state || "complete",
    walkable: Boolean(building.walkable),
    completeness: getBuildingCompleteness(building),
    constructionCost: getBuildingConstructionCost(building.type),
  };
}

function serializeTask(task) {
  if (!task) return null;

  if (![ "move", "play", "buildHouse", "demolish" ].includes(task.type)) {
    return null;
  }

  if (task.type === "play") {
    return { type: task.type };
  }

  return {
    type: task.type,
    toX: clampInteger(task.toX, 0, map.width - 1, 0),
    toY: clampInteger(task.toY, 0, map.height - 1, 0),
  };
}

function serializeUnit(currentUnit) {
  if (!currentUnit) return null;

  if (currentUnit.move) {
    const didReachDestination =
      currentUnit.task?.type === "move" &&
      currentUnit.task.toX === currentUnit.move.toX &&
      currentUnit.task.toY === currentUnit.move.toY;

    return {
      id: currentUnit.id || "unit_01",
      name: normalizeUnitName(currentUnit.name),
      x: currentUnit.move.toX,
      y: currentUnit.move.toY,
      facing: currentUnit.move.direction || currentUnit.facing || "west",
      homeBuildingId: getUnitHomeBuildingId(currentUnit),
      staminaMax: getUnitMaxStamina(currentUnit),
      stamina: getUnitStamina(currentUnit),
      task: didReachDestination ? null : serializeTask(currentUnit.task),
    };
  }

  return {
    id: currentUnit.id || "unit_01",
    name: normalizeUnitName(currentUnit.name),
    x: currentUnit.x,
    y: currentUnit.y,
    facing: currentUnit.facing || "west",
    homeBuildingId: getUnitHomeBuildingId(currentUnit),
    staminaMax: getUnitMaxStamina(currentUnit),
    stamina: getUnitStamina(currentUnit),
    task: serializeTask(currentUnit.task),
  };
}

function serializeCells(cells = map.cells) {
  return cells.map((row) => row.map((cell) => serializeCell(cell)));
}

function serializeBuildings(items = buildings, width = map.width, height = map.height) {
  return items.map((building) => serializeBuilding(building, width, height)).filter(Boolean);
}

function serializeCurrentState() {
  return {
    version: saveVersion,
    map: {
      width: map.width,
      height: map.height,
      cells: serializeCells(),
    },
    buildings: serializeBuildings(),
    units: getUnits().map((currentUnit) => serializeUnit(currentUnit)).filter(Boolean),
    turn: currentTurn,
    autoAdvanceTurns,
  };
}

function writeSaveFile(fileName, state) {
  const storageKey = getSaveFileKey(fileName);

  if (!storageKey) return false;

  try {
    window.localStorage.setItem(storageKey, JSON.stringify(state));
    return true;
  } catch (error) {
    console.warn(`Could not save file ${fileName}.`, error);
    return false;
  }
}

function writeRawSaveFile(fileName, rawContents) {
  const storageKey = getSaveFileKey(fileName);

  if (!storageKey || typeof rawContents !== "string") return false;

  try {
    window.localStorage.setItem(storageKey, rawContents);
    return true;
  } catch (error) {
    console.warn(`Could not write raw save file ${fileName}.`, error);
    return false;
  }
}

function saveStateToFile(fileName, mode = interactionMode) {
  const normalizedName = sanitizeFileName(fileName);

  if (!normalizedName) return false;

  const didSave = writeSaveFile(normalizedName, serializeCurrentState());

  if (!didSave) return false;

  writeCurrentFileName(mode, normalizedName);
  updatePersistenceControls();
  return true;
}

function readSaveFile(fileName) {
  const storageKey = getSaveFileKey(fileName);

  if (!storageKey) return null;

  try {
    const raw = window.localStorage.getItem(storageKey);

    if (!raw) return null;
    return JSON.parse(raw);
  } catch (error) {
    console.warn(`Could not load file ${fileName}.`, error);
    return null;
  }
}

function readRawSaveFile(fileName) {
  const storageKey = getSaveFileKey(fileName);

  if (!storageKey) return null;

  try {
    const raw = window.localStorage.getItem(storageKey);
    return typeof raw === "string" ? raw : null;
  } catch (error) {
    console.warn(`Could not load raw save file ${fileName}.`, error);
    return null;
  }
}

function isCompatibleSaveState(state) {
  return Boolean(state) && state.version === saveVersion;
}

async function showImportFilePicker() {
  if (typeof window.showOpenFilePicker === "function") {
    const [handle] = await window.showOpenFilePicker({
      multiple: false,
      excludeAcceptAllOption: false,
      types: [
        {
          description: "JSON save files",
          accept: { "application/json": [".json"] },
        },
      ],
    });

    if (!handle) return null;

    const file = await handle.getFile();
    return file || null;
  }

  return new Promise((resolve) => {
    const input = document.createElement("input");
    input.type = "file";
    input.accept = ".json,application/json";
    input.style.display = "none";
    document.body.append(input);

    const cleanup = () => {
      input.remove();
    };

    input.addEventListener(
      "change",
      () => {
        const file = input.files?.[0] || null;
        cleanup();
        resolve(file);
      },
      { once: true },
    );
    input.addEventListener(
      "cancel",
      () => {
        cleanup();
        resolve(null);
      },
      { once: true },
    );

    input.click();
  });
}

async function saveTextFileToDisk(fileName, rawContents) {
  if (typeof window.showSaveFilePicker === "function") {
    const handle = await window.showSaveFilePicker({
      suggestedName: `${fileName}.json`,
      types: [
        {
          description: "JSON save files",
          accept: { "application/json": [".json"] },
        },
      ],
    });

    if (!handle) return false;

    const writable = await handle.createWritable();
    await writable.write(rawContents);
    await writable.close();
    return true;
  }

  const blob = new Blob([rawContents], { type: "application/json" });
  const objectUrl = URL.createObjectURL(blob);
  const link = document.createElement("a");

  link.href = objectUrl;
  link.download = `${fileName}.json`;
  document.body.append(link);
  link.click();
  link.remove();
  URL.revokeObjectURL(objectUrl);
  return true;
}

async function exportSaveFile(fileName) {
  const raw = readRawSaveFile(fileName);

  if (!raw) {
    window.alert(strings.messages.saveNotFound(fileName));
    return false;
  }

  try {
    await saveTextFileToDisk(fileName, raw);
    return true;
  } catch (error) {
    console.warn(`Could not export save file ${fileName}.`, error);
    return false;
  }
}

async function importSaveIntoSlot(fileName) {
  let file = null;

  try {
    file = await showImportFilePicker();
  } catch (error) {
    console.warn("Could not open import file picker.", error);
    return false;
  }

  if (!file) {
    return false;
  }

  const fallbackName = sanitizeFileName(file.name.replace(/\.[^.]+$/, ""));
  const normalizedName = sanitizeFileName(fileName) || fallbackName;

  if (!normalizedName) {
    window.alert(strings.messages.missingSaveName);
    return false;
  }

  let rawContents = "";

  try {
    rawContents = await file.text();
  } catch (error) {
    console.warn("Could not read imported save file.", error);
    return false;
  }

  let parsed = null;

  try {
    parsed = JSON.parse(rawContents);
  } catch (error) {
    window.alert(strings.messages.invalidImportFile);
    return false;
  }

  if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) {
    window.alert(strings.messages.invalidSaveData);
    return false;
  }

  if (!writeRawSaveFile(normalizedName, JSON.stringify(parsed, null, 2))) {
    return false;
  }

  if (slotPanelState) {
    slotPanelState.value = normalizedName;
    saveSlotInput.value = normalizedName;
  }

  renderSaveSlotList();
  updatePersistenceControls();
  return true;
}

function buildGeneratedMapCells(
  width = defaultMapConfig.width,
  height = defaultMapConfig.height,
) {
  const cells = [];

  for (let y = 0; y < height; y += 1) {
    const row = [];

    for (let x = 0; x < width; x += 1) {
      const riverCenter = 8 + Math.sin(y * 0.38) * 4 + y * 0.34;
      const lakeA = distance(x, y, 31, 13) < 4.2;
      const lakeB = distance(x, y, 9, 42) < 3.5;
      const river = Math.abs(x - riverCenter) < 1.1 && y > 3 && y < height - 3;
      const northWater = y < 3 && x < 18 + y * 3;
      const eastWater = x > width - 5 && y > 19 && y < 34;
      const mountainBand =
        (x > 24 && y > 24 && (x + y) % 3 !== 0) ||
        (x > 17 && x < 27 && y > 6 && y < 13 && (x + y) % 4 !== 0);
      const forestBand =
        ((x + y) % 7 === 0 && y > 4) ||
        (x > 4 && x < 15 && y > 20 && y < 52 && (x * 2 + y) % 5 !== 0);

      let type = "grass";
      if (river || lakeA || lakeB || northWater || eastWater) type = "water";
      else if (mountainBand) type = "mountain";
      else if (forestBand) type = "forest";

      row.push(createCell(x, y, type));
    }

    cells.push(row);
  }

  return cells;
}

function buildEmptyMapCells(
  width = defaultMapConfig.width,
  height = defaultMapConfig.height,
) {
  const cells = [];

  for (let y = 0; y < height; y += 1) {
    const row = [];

    for (let x = 0; x < width; x += 1) {
      row.push(createCell(x, y, "grass"));
    }

    cells.push(row);
  }

  return cells;
}

function getCellInCells(cells, width, height, x, y) {
  if (x < 0 || x >= width || y < 0 || y >= height) return null;
  return cells[y]?.[x] || null;
}

function getNeighborCellInCells(cells, width, height, cell, direction) {
  if (!cell) return null;

  if (["northWest", "northEast", "southEast", "southWest"].includes(direction)) {
    const isOddRow = cell.y % 2 === 1;
    const offsets = {
      northWest: { x: isOddRow ? 0 : -1, y: -1 },
      northEast: { x: isOddRow ? 1 : 0, y: -1 },
      southEast: { x: isOddRow ? 1 : 0, y: 1 },
      southWest: { x: isOddRow ? 0 : -1, y: 1 },
    };
    const offset = offsets[direction];

    return getCellInCells(cells, width, height, cell.x + offset.x, cell.y + offset.y);
  }

  if (["north", "east", "south", "west"].includes(direction)) {
    const offsets = {
      north: { x: 0, y: -2 },
      east: { x: 1, y: 0 },
      south: { x: 0, y: 2 },
      west: { x: -1, y: 0 },
    };
    const offset = offsets[direction];

    return getCellInCells(cells, width, height, cell.x + offset.x, cell.y + offset.y);
  }

  return null;
}

function canEnterUnoccupiedCell(cell) {
  return Boolean(cell) && cell.type !== "water";
}

function markCellsVisitedByUnits(cells, units) {
  if (!Array.isArray(cells) || !Array.isArray(units)) return;

  for (const currentUnit of units) {
    if (!currentUnit) continue;

    const cell = cells[currentUnit.y]?.[currentUnit.x];

    if (cell) {
      cell.visited = true;
    }
  }
}

function createDefaultUnitState(cells, width, height) {
  const spawn = findNearestPassableCellInCells(
    cells,
    width,
    height,
    Math.floor(width / 2),
    Math.floor(height / 2),
  );

  return spawn
      ? {
          id: "unit_01",
          name: getDefaultUnitName(),
          x: spawn.x,
          y: spawn.y,
          facing: "west",
          homeBuildingId: null,
          staminaMax: getDefaultUnitStamina(),
          stamina: getDefaultUnitStamina(),
          task: null,
          turnRoute: null,
        }
    : null;
}

function createBuildingId() {
  let maxIndex = 0;

  for (const building of buildings) {
    const match = /^building_(\d+)$/.exec(building?.id || "");

    if (!match) continue;
    maxIndex = Math.max(maxIndex, Number.parseInt(match[1], 10) || 0);
  }

  return `building_${String(maxIndex + 1).padStart(2, "0")}`;
}

function createHouseConstructionAtCell(cell) {
  if (!canBuildHouseOnCell(cell)) return null;

  const building = {
    id: createBuildingId(),
    type: "house",
    subtype: chooseBuildingSubtype("house") || "house_01",
    x: cell.x,
    y: cell.y,
    width: getDefaultBuildingWidth(),
    height: getDefaultBuildingHeight(),
    state: "construction",
    walkable: isBuildingWalkable("house"),
    completeness: 0,
    constructionCost: getBuildingConstructionCost("house"),
  };

  buildings.push(building);
  return building;
}

function createDefaultBuildingsState(cells, width, height, units) {
  const spawnUnit = Array.isArray(units) ? units[0] : null;

  if (!spawnUnit) return [];

  const spawnCell = getCellInCells(cells, width, height, spawnUnit.x, spawnUnit.y);

  if (!spawnCell) return [];

  const placementDirections = [
    "east",
    "west",
    "southEast",
    "southWest",
    "northEast",
    "northWest",
    "south",
    "north",
  ];
  const placementCells = [];
  const occupied = new Set([`${spawnUnit.x},${spawnUnit.y}`]);

  for (const direction of placementDirections) {
    const neighbor = getNeighborCellInCells(cells, width, height, spawnCell, direction);

    if (!canEnterUnoccupiedCell(neighbor)) continue;
    const key = `${neighbor.x},${neighbor.y}`;

    if (occupied.has(key)) continue;

    occupied.add(key);
    placementCells.push(neighbor);
  }

  if (placementCells.length === 0) return [];

  const previewBuildings = [
    {
      state: "complete",
      subtype: chooseBuildingSubtype("house") || "house_01",
      completeness: 1,
    },
  ];

  return previewBuildings
    .slice(0, placementCells.length)
    .map((preview, index) => {
      const cell = placementCells[index];

      return {
        id: `building_${String(index + 1).padStart(2, "0")}`,
        type: "house",
        subtype: preview.subtype,
        x: cell.x,
        y: cell.y,
        width: getDefaultBuildingWidth(),
        height: getDefaultBuildingHeight(),
        state: preview.state,
        walkable: isBuildingWalkable("house"),
        completeness: preview.completeness,
        constructionCost: getBuildingConstructionCost("house"),
      };
    });
}

function markCellsVisitedByBuildings(cells, buildingsState) {
  if (!Array.isArray(cells) || !Array.isArray(buildingsState)) return;

  for (const building of buildingsState) {
    for (let y = building.y; y < building.y + building.height; y += 1) {
      for (let x = building.x; x < building.x + building.width; x += 1) {
        const cell = cells[y]?.[x];

        if (cell) {
          cell.visited = true;
        }
      }
    }
  }
}

function createGeneratedState(mode, buildCells = buildGeneratedMapCells) {
  const width = defaultMapConfig.width;
  const height = defaultMapConfig.height;
  const cells = buildCells(width, height);
  const defaultUnit = createDefaultUnitState(cells, width, height);
  const units = defaultUnit ? [defaultUnit] : [];
  const defaultBuildings = createDefaultBuildingsState(cells, width, height, units);

  if (units[0] && defaultBuildings[0]) {
    units[0].homeBuildingId = defaultBuildings[0].id;
  }

  markCellsVisitedByUnits(cells, units);
  markCellsVisitedByBuildings(cells, defaultBuildings);

  return {
    version: saveVersion,
    map: {
      width,
      height,
      cells: serializeCells(cells),
    },
    buildings: serializeBuildings(defaultBuildings, width, height),
    units,
    turn: 1,
    autoAdvanceTurns: true,
  };
}

function createDefaultState(mode) {
  return createGeneratedState(mode, buildGeneratedMapCells);
}

function normalizeMapState(rawMap) {
  const width = clampInteger(rawMap?.width, 1, 512, defaultMapConfig.width);
  const height = clampInteger(rawMap?.height, 1, 512, defaultMapConfig.height);
  const generatedCells = buildGeneratedMapCells(width, height);

  if (!Array.isArray(rawMap?.cells)) {
    throw new Error("Missing map cell data.");
  }

  for (let y = 0; y < height; y += 1) {
    const sourceRow = Array.isArray(rawMap.cells[y]) ? rawMap.cells[y] : [];

    for (let x = 0; x < width; x += 1) {
      const sourceCell = sourceRow[x];

      if (!sourceCell || !terrain[sourceCell.type]) continue;

      const cell = generatedCells[y][x];
      cell.type = sourceCell.type;
      if (typeof sourceCell.visited !== "boolean") {
        throw new Error("Missing explored state in map cell.");
      }
      cell.visited = sourceCell.visited;

      const variants = getTerrainVariants(cell.type);
      cell.variant = variants.some((variant) => variant.id === sourceCell.variant)
        ? sourceCell.variant
        : chooseTerrainVariant(cell.type);
    }
  }

  return {
    width,
    height,
    cells: generatedCells,
  };
}

function findNearestPassableCellInCells(cells, width, height, startX, startY) {
  let best = null;
  let bestDistance = Number.POSITIVE_INFINITY;

  for (let y = 0; y < height; y += 1) {
    for (let x = 0; x < width; x += 1) {
      const cell = cells[y]?.[x];

      if (!canEnterUnoccupiedCell(cell)) continue;

      const cellDistance = distance(x, y, startX, startY);

      if (cellDistance >= bestDistance) continue;

      best = cell;
      bestDistance = cellDistance;
    }
  }

  return best;
}

function normalizeDirection(direction) {
  return [
    "northWest",
    "northEast",
    "southEast",
    "southWest",
    "north",
    "east",
    "south",
    "west",
  ].includes(direction)
    ? direction
    : "west";
}

function normalizeTask(task, currentX, currentY) {
  if (!task) return null;

  const type = task.type;

  if (![ "move", "play", "buildHouse", "demolish" ].includes(type)) {
    return null;
  }

  if (type === "play") {
    return { type };
  }

  const toX = clampInteger(task.toX, 0, map.width - 1, currentX);
  const toY = clampInteger(task.toY, 0, map.height - 1, currentY);
  const destinationCell = getCell(toX, toY);

  if (!destinationCell) return null;

  if (type === "move") {
    if (!canUnitEnter(destinationCell)) return null;
    if (toX === currentX && toY === currentY) return null;
  } else if (!areCellsAdjacent(currentX, currentY, toX, toY)) {
    return null;
  } else if (type === "buildHouse") {
    const building = getBuildingAtCell(toX, toY);

    if (!building || building.type !== "house") {
      return null;
    }
  } else {
    const building = getBuildingAtCell(toX, toY);

    if (!building || building.state !== "abandoned") {
      return null;
    }
  }

  return { type, toX, toY };
}

function preserveTask(task) {
  if (!task || !["move", "play", "buildHouse", "demolish"].includes(task.type)) return null;

  if (task.type === "play") {
    return { type: task.type };
  }

  return {
    type: task.type,
    toX: clampInteger(task.toX, 0, map.width - 1, 0),
    toY: clampInteger(task.toY, 0, map.height - 1, 0),
  };
}

function normalizeBuildingState(state) {
  return ["complete", "construction", "abandoned"].includes(state)
    ? state
    : "complete";
}

function normalizeBuildingSubtype(type, subtype) {
  const variants = getBuildingSubtypeVariants(type);

  if (variants.some((variant) => variant.id === subtype)) {
    return subtype;
  }

  return variants[0]?.id || null;
}

function normalizeBuildingsState(rawBuildings) {
  if (!Array.isArray(rawBuildings)) {
    throw new Error("Missing building data.");
  }

  return rawBuildings.map((sourceBuilding, index) => {
    const type = sourceBuilding?.type;

    if (!getBuildingSpec(type)) {
      throw new Error(`Unsupported building type: ${type}`);
    }

    const x = clampInteger(sourceBuilding.x, 0, map.width - 1, 0);
    const y = clampInteger(sourceBuilding.y, 0, map.height - 1, 0);
    const width = Math.max(
      1,
      Math.min(
        map.width - x,
        clampInteger(sourceBuilding.width, 1, map.width, getDefaultBuildingWidth()),
      ),
    );
    const height = Math.max(
      1,
      Math.min(
        map.height - y,
        clampInteger(sourceBuilding.height, 1, map.height, getDefaultBuildingHeight()),
      ),
    );

    return {
      id: typeof sourceBuilding.id === "string" ? sourceBuilding.id : `building_${index + 1}`,
      type,
      subtype: normalizeBuildingSubtype(type, sourceBuilding.subtype),
      x,
      y,
      width,
      height,
      state: normalizeBuildingState(sourceBuilding.state),
      walkable: typeof sourceBuilding.walkable === "boolean"
        ? sourceBuilding.walkable
        : isBuildingWalkable(type),
      completeness: getBuildingCompleteness(sourceBuilding),
      constructionCost: getBuildingConstructionCost(type),
    };
  });
}

function normalizeUnitsState(rawUnits, mode) {
  const sourceUnits = Array.isArray(rawUnits) ? rawUnits : [];

  if (sourceUnits.length === 0) {
    if (mode !== interactionModes.play) return [];

    const fallbackUnit = createDefaultUnitState(map.cells, map.width, map.height);
    return fallbackUnit
      ? [
          {
            ...fallbackUnit,
            selected: false,
            move: null,
            turnRoute: null,
            lastStepFromX: null,
            lastStepFromY: null,
          },
        ]
      : [];
  }
  const normalizedUnits = [];
  const occupiedKeys = new Set();

  for (let index = 0; index < sourceUnits.length; index += 1) {
    const sourceUnit = sourceUnits[index];
    let x = clampInteger(sourceUnit?.x, 0, map.width - 1, Math.floor(map.width / 2));
    let y = clampInteger(sourceUnit?.y, 0, map.height - 1, Math.floor(map.height / 2));
    let cell = getCell(x, y);

    if (!canUnitEnter(cell, null, occupiedKeys)) {
      const fallbackCell = findNearestPassableCell(x, y, null, occupiedKeys);

      if (!fallbackCell) {
        continue;
      }

      x = fallbackCell.x;
      y = fallbackCell.y;
      cell = fallbackCell;
    }

    occupiedKeys.add(createCellKey(cell.x, cell.y));

    const staminaMax = Math.max(
      1,
      clampInteger(sourceUnit?.staminaMax, 1, 999, getDefaultUnitStamina()),
    );

    normalizedUnits.push({
      id: typeof sourceUnit?.id === "string" ? sourceUnit.id : `unit_${index + 1}`,
      name: normalizeUnitName(sourceUnit?.name),
      x: cell.x,
      y: cell.y,
      facing: normalizeDirection(sourceUnit?.facing),
      homeBuildingId:
        typeof sourceUnit?.homeBuildingId === "string" && sourceUnit.homeBuildingId
          ? sourceUnit.homeBuildingId
          : null,
      staminaMax,
      stamina: Math.max(0, clampInteger(sourceUnit?.stamina, 0, 999, staminaMax)),
      selected: false,
      task:
        mode !== interactionModes.play
          ? preserveTask(sourceUnit?.task)
          : normalizeTask(sourceUnit?.task, cell.x, cell.y),
      move: null,
      turnRoute: null,
      lastStepFromX: null,
      lastStepFromY: null,
    });
  }

  return normalizedUnits;
}

function applyStateSnapshot(state, mode, { recenter = true } = {}) {
  if (animationFrameId) {
    cancelAnimationFrame(animationFrameId);
    animationFrameId = 0;
  }

  clearPendingAutoAdvance();
  clearEditHoverState();
  hideTileMenu();

  const nextState = state || createDefaultState(mode);
  const nextMap = normalizeMapState(nextState.map);

  map.width = nextMap.width;
  map.height = nextMap.height;
  map.cells = nextMap.cells;
  buildings = normalizeBuildingsState(nextState.buildings);
  units = normalizeUnitsState(nextState.units, mode);
  syncActiveUnit();
  selectedUnitAction = unitActions.walk;
  currentTurn = Math.max(1, clampInteger(nextState.turn, 1, 999999, 1));
  autoAdvanceTurns =
    typeof nextState.autoAdvanceTurns === "boolean" ? nextState.autoAdvanceTurns : true;

  setTextContent(mapSizeReadouts, strings.readouts.mapSize(map.width, map.height));
  resetTileReadout();
  invalidateStaticLayer();
  invalidateStaticUnitsLayer();
  updateUnitReadout();
  updateTurnControls();
  updateInteractionModeUi();
  layoutCanvas();

  if (recenter) {
    requestAnimationFrame(() => restoreViewportCenter({ x: 0.5, y: 0.5 }));
  }

  draw();
  if (shouldAnimateWorkingUnits()) {
    scheduleAnimation();
  }
  maybeAutoAdvanceTurn();
}

function loadFileIntoMode(fileName, mode, options) {
  const normalizedName = sanitizeFileName(fileName);

  if (!normalizedName) return false;

  const state = readSaveFile(normalizedName);

  if (!state) return false;
  if (!isCompatibleSaveState(state)) {
    console.warn(`Save slot ${normalizedName} is obsolete and cannot be loaded.`);
    return false;
  }

  try {
    applyStateSnapshot(state, mode, options);
    writeCurrentFileName(mode, normalizedName);
    return true;
  } catch (error) {
    console.warn(`Could not apply save slot ${normalizedName}.`, error);
    return false;
  }
}

function loadCurrentFileForMode(mode, options) {
  const currentFileName = getCurrentFileName(mode);

  if (!currentFileName) {
    applyStateSnapshot(createDefaultState(mode), mode, options);
    return false;
  }

  if (loadFileIntoMode(currentFileName, mode, options)) {
    return true;
  }

  writeCurrentFileName(mode, null);
  applyStateSnapshot(createDefaultState(mode), mode, options);
  return false;
}

function loadState(mode = interactionMode) {
  if (!mode) return false;

  openSaveSlotPanel("load", { targetMode: mode });
  return true;
}

function saveStateAs(mode = interactionMode) {
  if (!mode) return false;

  openSaveSlotPanel("saveAs", { targetMode: mode });
  return true;
}

function saveState(mode = interactionMode) {
  const currentFileName = getCurrentFileName(mode);

  if (!currentFileName) {
    return saveStateAs(mode);
  }

  return saveStateToFile(currentFileName, mode);
}

function autosavePlayState() {
  return saveStateToFile(autosaveSlotName, interactionModes.play);
}

function getUnits() {
  return units;
}

function hasAssignedTask(currentUnit) {
  return Boolean(currentUnit?.task);
}

function getActionForTask(task) {
  if (task?.type === "play") {
    return unitActions.play;
  }

  if (task?.type === "buildHouse") {
    return unitActions.buildHouse;
  }

  if (task?.type === "demolish") {
    return unitActions.demolish;
  }

  return unitActions.walk;
}

function getDefaultActionForCompletedTask(taskType) {
  return taskType === "move" ? unitActions.walk : unitActions.wait;
}

function applyCompletedTaskDefaultAction(taskType, currentUnit) {
  const selectedUnit = getSelectedUnit();

  if (selectedUnit && selectedUnit !== currentUnit) {
    return;
  }

  selectedUnitAction = getDefaultActionForCompletedTask(taskType);
}

function getCurrentSelectedUnitAction() {
  const selectedUnit = getSelectedUnit();

  if (selectedUnit?.task && selectedUnit.task.type !== "play") {
    return getActionForTask(selectedUnit.task);
  }

  return normalizeUnitAction(selectedUnitAction);
}

function isWorkingTask(task) {
  return task?.type === "buildHouse" || task?.type === "demolish" || task?.type === "play";
}

function isUnitWorking(currentUnit) {
  return Boolean(currentUnit) && !currentUnit.move && isWorkingTask(currentUnit.task);
}

function hasWorkingUnits() {
  return getUnits().some((currentUnit) => isUnitWorking(currentUnit));
}

function getWorkingUnitFrameIndex(now = performance.now()) {
  if (unitSprite.workFrames.length <= 1) {
    return 0;
  }

  return Math.floor(now / unitSprite.workFrameDuration) % unitSprite.workFrames.length;
}

function shouldAnimateWorkingUnits() {
  return isPlayMode() && !mainMenuOpen && hasWorkingUnits();
}

function shouldAnimateSelectionMarker() {
  return isPlayMode() && !mainMenuOpen && Boolean(getSelectedUnit());
}

function getUnitTaskDirection(currentUnit) {
  if (!isWorkingTask(currentUnit?.task)) {
    return currentUnit?.facing || "west";
  }

  if (currentUnit.task?.type === "play") {
    const direction = currentUnit?.facing || "west";
    return direction === "south" ? "southEast" : direction;
  }

  const direction = getMoveDirection(
    currentUnit.x,
    currentUnit.y,
    currentUnit.task.toX,
    currentUnit.task.toY,
  );

  if (direction === "south") {
    return "southEast";
  }

  return direction;
}

function isUnitAnimating(currentUnit) {
  return Boolean(currentUnit?.move);
}

function isUnitIdle(currentUnit) {
  return Boolean(currentUnit) && !hasAssignedTask(currentUnit) && !isUnitAnimating(currentUnit);
}

function getIdleUnits() {
  return getUnits().filter((currentUnit) => isUnitIdle(currentUnit));
}

function getFirstIdleUnit() {
  return getIdleUnits()[0] || null;
}

function getNextIdleUnit(fromUnit = getSelectedUnit()) {
  const idleUnits = getIdleUnits();

  if (idleUnits.length <= 1) {
    return null;
  }

  const currentIndex = idleUnits.findIndex((currentUnit) => currentUnit === fromUnit);

  if (currentIndex < 0) {
    return idleUnits[0];
  }

  return idleUnits[(currentIndex + 1) % idleUnits.length] || null;
}

function selectNextIdleUnit({
  fromUnit = getSelectedUnit(),
  defaultAction = unitActions.walk,
  scrollIntoView = true,
} = {}) {
  const nextIdleUnit = getNextIdleUnit(fromUnit);

  if (!nextIdleUnit) {
    return false;
  }

  selectUnit(nextIdleUnit, { scrollIntoView, defaultAction });
  return true;
}

function everyUnitHasOngoingTask() {
  const units = getUnits();

  return units.length > 0 && units.every((currentUnit) => hasAssignedTask(currentUnit));
}

function canAdvanceTurn() {
  return (
    !mainMenuOpen &&
    isPlayMode() &&
    !turnResolutionActive &&
    !getUnits().some((currentUnit) => isUnitAnimating(currentUnit))
  );
}

function updateTurnReadout() {
  setTextContent(turnReadouts, strings.readouts.turn(currentTurn));
}

function updateTurnControls() {
  updateTurnReadout();
  setCheckedState(autoPassInputs, autoAdvanceTurns);
  setDisabledState(nextTurnButtons, !canAdvanceTurn());
  const shouldHighlight = canAdvanceTurn() && everyUnitHasOngoingTask();

  for (const button of nextTurnButtons) {
    button.classList.toggle("is-highlighted", shouldHighlight);
  }

  updatePersistenceControls();
}

function createMoveTask(destinationCell) {
  return {
    type: "move",
    toX: destinationCell.x,
    toY: destinationCell.y,
  };
}

function createPlayTask() {
  return {
    type: "play",
  };
}

function createBuildHouseTask(destinationCell) {
  return {
    type: "buildHouse",
    toX: destinationCell.x,
    toY: destinationCell.y,
  };
}

function createDemolishTask(destinationCell) {
  return {
    type: "demolish",
    toX: destinationCell.x,
    toY: destinationCell.y,
  };
}

function assignUnitTask(task, currentUnit = getSelectedUnit()) {
  if (!currentUnit || currentUnit.move || !task) return false;

  const previousTaskType = currentUnit.task?.type || null;

  currentUnit.task = task;
  currentUnit.turnRoute = null;
  currentUnit.lastStepFromX = null;
  currentUnit.lastStepFromY = null;
  unit = currentUnit;
  selectedUnitAction = task.type === "play" ? unitActions.play : getActionForTask(task);
  invalidateStaticUnitsLayer();
  updateUnitReadout();
  updateTurnControls();
  if (shouldAnimateWorkingUnits()) {
    scheduleAnimation();
  }
  draw();

  if (!turnResolutionActive && previousTaskType === "play") {
    clearQueuedAutoAdvanceFrame();
  }

  if (
    !turnResolutionActive &&
    previousTaskType === "play" &&
    task.type !== "play" &&
    autoAdvanceTurns &&
    canAdvanceTurn() &&
    getIdleUnits().length === 0 &&
    everyUnitHasOngoingTask()
  ) {
    advanceTurn();
    return true;
  }

  maybeAutoAdvanceTurn();
  return true;
}

function queueUnitMoveTask(destinationCell, currentUnit = getSelectedUnit()) {
  if (!currentUnit || currentUnit.move) return;
  if (!canUnitEnter(destinationCell, currentUnit)) return;
  if (destinationCell.x === currentUnit.x && destinationCell.y === currentUnit.y) return;

  assignUnitTask(createMoveTask(destinationCell), currentUnit);
}

function queueUnitPlayTask(currentUnit = getSelectedUnit()) {
  if (!currentUnit || currentUnit.move) return;

  assignUnitTask(createPlayTask(), currentUnit);
}

function queueUnitBuildHouseTask(destinationCell, currentUnit = getSelectedUnit()) {
  if (!currentUnit || currentUnit.move || !canBuildHouseOnCell(destinationCell)) return;
  if (!areCellsAdjacent(currentUnit.x, currentUnit.y, destinationCell.x, destinationCell.y)) return;

  const building = createHouseConstructionAtCell(destinationCell);

  if (!building) return;

  const cell = getCell(destinationCell.x, destinationCell.y);

  if (cell && !cell.visited) {
    cell.visited = true;
  }

  invalidateStaticLayer();
  assignUnitTask(createBuildHouseTask(destinationCell), currentUnit);
}

function queueUnitDemolishTask(destinationCell, currentUnit = getSelectedUnit()) {
  if (
    !currentUnit ||
    currentUnit.move ||
    !areCellsAdjacent(currentUnit.x, currentUnit.y, destinationCell.x, destinationCell.y)
  ) {
    return;
  }

  const building = getBuildingAtCell(destinationCell.x, destinationCell.y);

  if (!building || building.state !== "abandoned") return;

  assignUnitTask(createDemolishTask(destinationCell), currentUnit);
}

function resolveBuildHouseTask(currentUnit) {
  const targetCell = getCell(currentUnit.task?.toX, currentUnit.task?.toY);

  if (!targetCell || !areCellsAdjacent(currentUnit.x, currentUnit.y, targetCell.x, targetCell.y)) {
    applyCompletedTaskDefaultAction("buildHouse", currentUnit);
    currentUnit.task = null;
    currentUnit.turnRoute = null;
    invalidateStaticUnitsLayer();
    return;
  }

  const building = getBuildingAtCell(targetCell.x, targetCell.y);

  if (!building || building.type !== "house") {
    applyCompletedTaskDefaultAction("buildHouse", currentUnit);
    currentUnit.task = null;
    currentUnit.turnRoute = null;
    invalidateStaticUnitsLayer();
    return;
  }

  const nextCompleteness = clamp(
    getBuildingCompleteness(building) +
      getBuildingWorkCompletenessDelta("buildHouse", building.type),
    0,
    1,
  );

  turnResolutionHadWork = true;
  building.state = nextCompleteness >= 1 ? "complete" : "construction";
  building.completeness = nextCompleteness;
  currentUnit.stamina = 0;
  invalidateStaticLayer();

  if (nextCompleteness >= 1) {
    spawnUnitFromHouse(building);
    applyCompletedTaskDefaultAction("buildHouse", currentUnit);
    currentUnit.task = null;
    currentUnit.turnRoute = null;
    invalidateStaticUnitsLayer();
  }
}

function resolveDemolishTask(currentUnit) {
  const targetCell = getCell(currentUnit.task?.toX, currentUnit.task?.toY);

  if (!targetCell || !areCellsAdjacent(currentUnit.x, currentUnit.y, targetCell.x, targetCell.y)) {
    applyCompletedTaskDefaultAction("demolish", currentUnit);
    currentUnit.task = null;
    currentUnit.turnRoute = null;
    invalidateStaticUnitsLayer();
    return;
  }

  const building = getBuildingAtCell(targetCell.x, targetCell.y);

  if (!building || building.state !== "abandoned") {
    applyCompletedTaskDefaultAction("demolish", currentUnit);
    currentUnit.task = null;
    currentUnit.turnRoute = null;
    invalidateStaticUnitsLayer();
    return;
  }

  const nextCompleteness = clamp(
    getBuildingCompleteness(building) +
      -getBuildingWorkCompletenessDelta("demolish", building.type),
    0,
    1,
  );

  turnResolutionHadWork = true;
  building.state = "abandoned";
  building.completeness = nextCompleteness;
  currentUnit.stamina = 0;
  invalidateStaticLayer();

  if (nextCompleteness <= 0) {
    buildings = buildings.filter((candidate) => candidate !== building);
    applyCompletedTaskDefaultAction("demolish", currentUnit);
    currentUnit.task = null;
    currentUnit.turnRoute = null;
    invalidateStaticUnitsLayer();
  }
}

function resolveUnitTask(currentUnit) {
  if (!currentUnit?.task) return false;

  if (currentUnit.task.type === "play") {
    turnResolutionHadWork = true;
    currentUnit.stamina = 0;
    return false;
  }

  if (currentUnit.task.type === "buildHouse") {
    resolveBuildHouseTask(currentUnit);
    return false;
  }

  if (currentUnit.task.type === "demolish") {
    resolveDemolishTask(currentUnit);
    return false;
  }

  if (currentUnit.task.type !== "move") {
    applyCompletedTaskDefaultAction(currentUnit.task.type, currentUnit);
    currentUnit.task = null;
    currentUnit.turnRoute = null;
    return false;
  }

  if (currentUnit.x === currentUnit.task.toX && currentUnit.y === currentUnit.task.toY) {
    applyCompletedTaskDefaultAction("move", currentUnit);
    currentUnit.task = null;
    currentUnit.turnRoute = null;
    return false;
  }

  const nextMove = getNextMoveStep(currentUnit, currentUnit.task);

  if (!nextMove) {
    applyCompletedTaskDefaultAction("move", currentUnit);
    currentUnit.task = null;
    currentUnit.turnRoute = null;
    return false;
  }

  const moveCost = getTerrainMoveCost(nextMove.cell);
  currentUnit.stamina = Math.max(0, getUnitStamina(currentUnit) - moveCost);

  turnResolutionHadAnimation = true;
  startUnitMove(nextMove.cell, nextMove.direction, currentUnit);
  return true;
}

function resetUnitsForTurn() {
  for (const currentUnit of getUnits()) {
    currentUnit.stamina = getUnitMaxStamina(currentUnit);
    currentUnit.turnRoute = null;
  }
}

function finishTurnResolution() {
  turnResolutionActive = false;
  turnResolutionPauseTimeoutId = 0;
  autosavePlayState();
  updateTurnControls();
  maybeAutoAdvanceTurn();
}

function startTurnResolutionPause() {
  if (turnResolutionPauseTimeoutId) {
    return;
  }

  if (shouldAnimateWorkingUnits()) {
    scheduleAnimation();
  }

  turnResolutionPauseTimeoutId = window.setTimeout(() => {
    finishTurnResolution();
  }, workTurnDisplayDelayMs);
}

function continueTurnResolution() {
  let startedAnimatedTask = false;

  for (const currentUnit of getUnits()) {
    if (!currentUnit.task || currentUnit.move) {
      continue;
    }

    if (getUnitStamina(currentUnit) <= 0) {
      continue;
    }

    startedAnimatedTask = resolveUnitTask(currentUnit) || startedAnimatedTask;

    if (startedAnimatedTask) {
      break;
    }
  }

  updateUnitReadout();
  updateTurnControls();
  draw();

  if (startedAnimatedTask) {
    return;
  }

  if (!turnResolutionHadAnimation && turnResolutionHadWork) {
    startTurnResolutionPause();
    return;
  }

  finishTurnResolution();
}

function updateBuildingsForTurn() {
  let didChange = false;
  const nextBuildings = [];

  for (const building of buildings) {
    if (building.state !== "abandoned" || isBuildingTargetedByDemolishTask(building)) {
      nextBuildings.push(building);
      continue;
    }

    const nextCompleteness = Math.max(
      0,
      getBuildingCompleteness(building) - getBuildingAbandonedDecay(building.type),
    );

    if (nextCompleteness !== building.completeness) {
      building.completeness = nextCompleteness;
      didChange = true;
    }

    if (nextCompleteness > 0) {
      nextBuildings.push(building);
    } else {
      didChange = true;
    }
  }

  buildings = nextBuildings;

  if (didChange) {
    invalidateStaticLayer();
  }
}

function advanceTurn() {
  if (!canAdvanceTurn()) return;

  clearPendingAutoAdvance();
  currentTurn += 1;
  updateBuildingsForTurn();
  turnResolutionActive = true;
  turnResolutionHadAnimation = false;
  turnResolutionHadWork = false;
  resetUnitsForTurn();
  continueTurnResolution();
}

function maybeAutoAdvanceTurn() {
  if (!canAdvanceTurn()) {
    if (turnResolutionActive) {
      clearQueuedAutoAdvanceFrame();
      updateTurnControls();
      return;
    }

    clearPendingAutoAdvance();
    updateTurnControls();
    return;
  }

  if (getIdleUnits().length > 0) {
    ensureIdleUnitSelection({ scrollIntoView: true });
    if (shouldAnimateWorkingUnits() || shouldAnimateSelectionMarker()) {
      scheduleAnimation();
    }
    clearPendingAutoAdvance();
    updateTurnControls();
    return;
  }

  if (!autoAdvanceTurns || !everyUnitHasOngoingTask()) {
    clearPendingAutoAdvance();
    updateTurnControls();
    return;
  }

  if (autoAdvanceQueued) return;

  autoAdvanceQueued = true;
  autoAdvanceFrameId = requestAnimationFrame(() => {
    autoAdvanceQueued = false;
    autoAdvanceFrameId = 0;

    if (autoAdvanceTurns && canAdvanceTurn() && everyUnitHasOngoingTask()) {
      advanceTurn();
    }
  });
}

function loadTileImages() {
  for (const [type, spec] of Object.entries(terrain)) {
    for (const variant of getTerrainVariants(type)) {
      loadImage(variant.image, tileImages);
    }
  }

  for (const imagePath of getBuildingImagePaths()) {
    loadImage(imagePath, buildingImages);
  }

  for (const imagePath of getShoreOverlayPaths()) {
    loadImage(imagePath, shoreOverlayImages);
  }

  loadImage(unitSprite.idleImage, unitImages);
  loadImage(unitSprite.northImage, unitImages);
  loadImage(unitSprite.southImage, unitImages);

  for (const imagePath of unitSprite.workFrames) {
    loadImage(imagePath, unitImages);
  }

  for (const imagePath of unitSprite.playFrames) {
    loadImage(imagePath, unitImages);
  }

  for (const imagePath of unitSprite.northMoveFrames) {
    loadImage(imagePath, unitImages);
  }

  for (const imagePath of unitSprite.southMoveFrames) {
    loadImage(imagePath, unitImages);
  }

  for (const imagePath of unitSprite.moveFrames) {
    loadImage(imagePath, unitImages);
  }
}

function getBuildingImagePaths() {
  const paths = [];

  for (const spec of Object.values(buildingCatalog)) {
    for (const variant of spec.subtypes || []) {
      paths.push(variant.image);
    }

    if (spec.abandonedImage) {
      paths.push(spec.abandonedImage);
    }

    if (spec.constructionImages) {
      paths.push(...Object.values(spec.constructionImages));
    }
  }

  return paths;
}

function getShoreOverlayPaths() {
  return [
    ...Object.values(shoreOverlays.edge),
    ...Object.values(shoreOverlays.corner),
  ];
}

function loadImage(imagePath, registry) {
  if (!imagePath || registry[imagePath]) return;

  const image = new Image();
  image.onload = () => {
    invalidateStaticLayer();
    invalidateStaticUnitsLayer();
    draw();
  };
  image.onerror = () => {
    console.warn(`Could not load image: ${imagePath}`);
    invalidateStaticLayer();
    invalidateStaticUnitsLayer();
    draw();
  };
  image.src = imagePath;
  registry[imagePath] = image;
}

function createCell(x, y, type) {
  return {
    x,
    y,
    type,
    variant: chooseTerrainVariant(type),
    visited: false,
  };
}

function setCellTerrain(cell, type) {
  if (cell.type !== type) {
    cell.type = type;
    cell.variant = chooseTerrainVariant(type);
    invalidateStaticLayer();
    return;
  }

  const previousVariant = cell.variant;

  ensureCellVariant(cell);

  if (cell.variant !== previousVariant) {
    invalidateStaticLayer();
  }
}

function ensureCellVariant(cell) {
  const variants = getTerrainVariants(cell.type);

  if (variants.some((variant) => variant.id === cell.variant)) return cell.variant;

  cell.variant = chooseTerrainVariant(cell.type);
  return cell.variant;
}

function chooseTerrainVariant(type) {
  const variants = getTerrainVariants(type);

  if (variants.length === 0) return null;

  const totalWeight = variants.reduce((total, variant) => total + (variant.weight ?? 1), 0);
  let roll = Math.random() * totalWeight;

  for (const variant of variants) {
    roll -= variant.weight ?? 1;

    if (roll < 0) return variant.id;
  }

  return variants[variants.length - 1].id;
}

function getTerrainVariants(type) {
  const spec = terrain[type];

  if (!spec) return [];
  if (spec.variants?.length) return spec.variants;
  if (spec.image) return [{ id: "default", label: spec.label, image: spec.image }];

  return [];
}

function getTerrainVariant(type, variantId) {
  const variants = getTerrainVariants(type);

  return variants.find((variant) => variant.id === variantId) || variants[0] || null;
}

function buildingOccupiesCell(building, x, y) {
  return (
    Boolean(building) &&
    x >= building.x &&
    x < building.x + building.width &&
    y >= building.y &&
    y < building.y + building.height
  );
}

function getBuildingsAtCell(x, y) {
  return buildings.filter((building) => buildingOccupiesCell(building, x, y));
}

function getBuildingAtCell(x, y) {
  return getBuildingsAtCell(x, y)[0] || null;
}

function getUnitAtCell(x, y, { excludeUnitId = null } = {}) {
  return (
    getUnits().find(
      (currentUnit) =>
        currentUnit &&
        currentUnit.id !== excludeUnitId &&
        currentUnit.x === x &&
        currentUnit.y === y,
    ) || null
  );
}

function getBlockingBuildingAtCell(x, y) {
  return (
    buildings.find(
      (building) => buildingOccupiesCell(building, x, y) && !building.walkable,
    ) || null
  );
}

function isBuildingTargetedByDemolishTask(building) {
  if (!building) return false;

  return getUnits().some(
    (currentUnit) =>
      currentUnit?.task?.type === "demolish" &&
      buildingOccupiesCell(building, currentUnit.task.toX, currentUnit.task.toY),
  );
}

function findAdjacentSpawnCell(x, y) {
  const originCell = getCell(x, y);

  if (!originCell) return null;

  for (const direction of [
    "east",
    "west",
    "southEast",
    "southWest",
    "northEast",
    "northWest",
    "south",
    "north",
  ]) {
    const neighbor = getNeighborByDirection(originCell, direction);

    if (canUnitEnter(neighbor)) {
      return neighbor;
    }
  }

  return null;
}

function spawnUnitFromHouse(building) {
  if (!building) return null;

  const spawnCell = findAdjacentSpawnCell(building.x, building.y);

  if (!spawnCell) {
    return null;
  }

  const spawnedUnit = {
    id: createUnitId(),
    name: getDefaultUnitName(),
    x: spawnCell.x,
    y: spawnCell.y,
    facing: "west",
    homeBuildingId: building.id,
    staminaMax: getDefaultUnitStamina(),
    stamina: getDefaultUnitStamina(),
    selected: false,
    task: null,
    move: null,
    turnRoute: null,
    lastStepFromX: null,
    lastStepFromY: null,
  };

  units.push(spawnedUnit);
  syncActiveUnit();

  const spawnTile = getCell(spawnCell.x, spawnCell.y);

  if (spawnTile && !spawnTile.visited) {
    spawnTile.visited = true;
    invalidateStaticLayer();
  }

  invalidateStaticUnitsLayer();
  return spawnedUnit;
}

function getBuildingVisual(building) {
  const spec = getBuildingSpec(building?.type);

  if (!spec) return null;

  if (building.state === "abandoned") {
    return {
      image: spec.abandonedImage,
      alpha: clamp(0.28 + getBuildingCompleteness(building) * 0.72, 0.2, 1),
    };
  }

  if (building.state === "construction") {
    const completeness = getBuildingCompleteness(building);
    const thresholds = getBuildingConstructionThresholds(building.type);

    if (completeness < thresholds.initialMax) {
      return {
        image: spec.constructionImages.initial,
        alpha: 1,
        yOffsetFactor: 0.2,
      };
    }

    if (completeness < thresholds.halfMax) {
      return {
        image: spec.constructionImages.half,
        alpha: 1,
      };
    }
  }

  const subtype = spec.subtypes.find((variant) => variant.id === building.subtype) || spec.subtypes[0];

  return subtype
    ? {
        image: subtype.image,
        alpha: 1,
      }
    : null;
}

function makeMap() {
  map.cells = buildGeneratedMapCells(map.width, map.height);
  setTextContent(mapSizeReadouts, strings.readouts.mapSize(map.width, map.height));
  invalidateStaticLayer();
}

function initializeUnit() {
  const spawn = createDefaultUnitState(map.cells, map.width, map.height);

  units = spawn
    ? [{ ...spawn, selected: false, move: null, turnRoute: null, lastStepFromX: null, lastStepFromY: null }]
    : [];
  syncActiveUnit();

  invalidateStaticUnitsLayer();
  updateUnitReadout();
}

function findNearestPassableCell(startX, startY, currentUnit = null, occupiedKeys = null) {
  let best = null;
  let bestDistance = Number.POSITIVE_INFINITY;

  for (let y = 0; y < map.height; y += 1) {
    for (let x = 0; x < map.width; x += 1) {
      const cell = getCell(x, y);

      if (!canUnitEnter(cell, currentUnit, occupiedKeys)) continue;

      const cellDistance = distance(x, y, startX, startY);

      if (cellDistance >= bestDistance) continue;

      best = cell;
      bestDistance = cellDistance;
    }
  }

  return best;
}

function canUnitEnter(cell, currentUnit = null, occupiedKeys = null) {
  return (
    Boolean(cell) &&
    cell.type !== "water" &&
    !getBlockingBuildingAtCell(cell.x, cell.y) &&
    !(
      occupiedKeys instanceof Set
        ? occupiedKeys.has(createCellKey(cell.x, cell.y))
        : Boolean(getUnitAtCell(cell.x, cell.y, { excludeUnitId: currentUnit?.id || null }))
    )
  );
}

function updateUnitReadout() {
  const selectedUnit = getSelectedUnit();
  const displayedUnit = selectedUnit || unit;

  if (!displayedUnit) {
    setTextContent(unitReadouts, strings.readouts.unitNone);
    updateUnitActionControls();
    return;
  }

  if (!selectedUnit && getUnits().length > 1) {
    setTextContent(unitReadouts, strings.readouts.unitUnselected(getUnits().length));
    updateUnitActionControls();
    return;
  }

  const stamina = getUnitStamina(displayedUnit);
  const staminaMax = getUnitMaxStamina(displayedUnit);
  const unitName = normalizeUnitName(displayedUnit.name);

  if (displayedUnit.move) {
    setTextContent(
      unitReadouts,
      strings.readouts.unitMoving(unitName, displayedUnit.move.toX, displayedUnit.move.toY, stamina, staminaMax),
    );
    updateUnitActionControls();
    return;
  }

  if (displayedUnit.task?.type === "move") {
    setTextContent(
      unitReadouts,
      strings.readouts.unitTaskMove(
        unitName,
        displayedUnit.task.toX,
        displayedUnit.task.toY,
        stamina,
        staminaMax,
      ),
    );
    updateUnitActionControls();
    return;
  }

  if (displayedUnit.task?.type === "play") {
    setTextContent(
      unitReadouts,
      strings.readouts.unitTaskPlay(unitName, stamina, staminaMax),
    );
    updateUnitActionControls();
    return;
  }

  if (displayedUnit.task?.type === "buildHouse") {
    setTextContent(
      unitReadouts,
      strings.readouts.unitTaskBuildHouse(
        unitName,
        displayedUnit.task.toX,
        displayedUnit.task.toY,
        stamina,
        staminaMax,
      ),
    );
    updateUnitActionControls();
    return;
  }

  if (displayedUnit.task?.type === "demolish") {
    setTextContent(
      unitReadouts,
      strings.readouts.unitTaskDemolish(
        unitName,
        displayedUnit.task.toX,
        displayedUnit.task.toY,
        stamina,
        staminaMax,
      ),
    );
    updateUnitActionControls();
    return;
  }

  const state = displayedUnit.selected ? strings.unitStates.selected : strings.unitStates.idle;
  setTextContent(
    unitReadouts,
    strings.readouts.unitState(unitName, state, displayedUnit.x, displayedUnit.y, stamina, staminaMax),
  );
  updateUnitActionControls();
}

function getVisibleTopBarMode() {
  if (mainMenuOpen || !interactionMode) return "menu";
  return interactionMode;
}

function updateUnitActionControls() {
  if (!unitActionBar) return;

  const selectedUnit = getSelectedUnit();
  const shouldShow = isPlayMode() && !mainMenuOpen && Boolean(selectedUnit);
  unitActionBar.hidden = !shouldShow;

  if (!shouldShow) {
    return;
  }

  const activeAction = getCurrentSelectedUnitAction();
  const disabled = Boolean(
    selectedUnit?.move || (selectedUnit?.task && selectedUnit.task.type !== "play"),
  );

  for (const button of unitActionButtons) {
    const action = normalizeUnitAction(button.dataset.unitAction);
    const isSelected = action === activeAction;

    button.classList.toggle("is-selected", isSelected);
    button.setAttribute("aria-pressed", isSelected ? "true" : "false");
    button.disabled = disabled;
  }
}

function selectUnit(currentUnit, { scrollIntoView = false, defaultAction = null } = {}) {
  if (!currentUnit) return false;

  let didChange = false;

  for (const candidate of getUnits()) {
    const shouldSelect = candidate === currentUnit;

    if (candidate.selected !== shouldSelect) {
      candidate.selected = shouldSelect;
      didChange = true;
    }
  }

  unit = currentUnit;
  selectedUnitAction = currentUnit.task
    ? currentUnit.task.type === "play"
      ? unitActions.play
      : getActionForTask(currentUnit.task)
    : normalizeUnitAction(defaultAction ?? unitActions.walk);

  if (scrollIntoView) {
    requestAnimationFrame(() => centerViewportOnUnit(currentUnit));
  }

  invalidateStaticUnitsLayer();
  updateUnitReadout();
  if (shouldAnimateSelectionMarker()) {
    scheduleAnimation();
  }
  draw();
  return didChange;
}

function ensureIdleUnitSelection({ force = false, scrollIntoView = false, defaultAction = null } = {}) {
  if (!isPlayMode() || mainMenuOpen || turnResolutionActive) {
    return false;
  }

  const idleUnit = getFirstIdleUnit();

  if (!idleUnit) {
    return false;
  }

  const selectedUnit = getSelectedUnit();

  if (force || !selectedUnit || !isUnitIdle(selectedUnit)) {
    selectUnit(idleUnit, { scrollIntoView, defaultAction });
    return true;
  }

  return false;
}

function updateInteractionModeUi() {
  const visibleTopBarMode = getVisibleTopBarMode();

  for (const [mode, topBar] of Object.entries(topBars)) {
    if (!topBar) continue;
    topBar.hidden = mode !== visibleTopBarMode;
  }

  if (playInspector) {
    playInspector.hidden = visibleTopBarMode !== interactionModes.play;
  }

  for (const button of newRandomMapButtons) {
    button.hidden = !isEditMode();
  }

  for (const button of newEmptyMapButtons) {
    button.hidden = !isEditMode();
  }

  setTextContent(appSubtitleElements, getAppSubtitleText());
  canvas.dataset.mode = interactionMode || "";

  updateTurnControls();
  updatePersistenceControls();
  updateUnitActionControls();
}

function isEditMode() {
  return interactionMode === interactionModes.edit;
}

function isPlayMode() {
  return interactionMode === interactionModes.play;
}

function resetTileReadout() {
  setTextContent(hoverReadouts, strings.readouts.tileNone);
}

function clearEditHoverState() {
  if (!hoverCell && !activeCell && tileMenu.hidden) {
    resetTileReadout();
    return;
  }

  hoverCell = null;
  hideTileMenu();
  resetTileReadout();
}

function clearUnitSelection() {
  let didChange = false;

  for (const currentUnit of getUnits()) {
    if (!currentUnit.selected) continue;
    currentUnit.selected = false;
    didChange = true;
  }

  if (!didChange) return;

  syncActiveUnit();
  selectedUnitAction = unitActions.walk;
  invalidateStaticUnitsLayer();
  updateUnitReadout();
}

function openMainMenu() {
  clearPendingAutoAdvance();
  closeGameActionMenu();
  closeSaveSlotPanel();
  clearEditHoverState();
  clearUnitSelection();
  mainMenuOpen = true;
  mainMenuOverlay.hidden = false;
  updateInteractionModeUi();
  mainMenuOverlay.querySelector(".main-menu-item:not(:disabled)")?.focus({ preventScroll: true });
  draw();
}

function setInteractionMode(nextMode) {
  if (!Object.values(interactionModes).includes(nextMode)) return;

  const didChange = interactionMode !== nextMode || mainMenuOpen;

  clearPendingAutoAdvance();
  interactionMode = nextMode;
  mainMenuOpen = false;
  mainMenuOverlay.hidden = true;
  closeGameActionMenu();
  closeSaveSlotPanel();
  clearEditHoverState();
  clearUnitSelection();
  invalidateStaticUnitsLayer();

  updateInteractionModeUi();

  if (didChange) {
    draw();
  }

  if (shouldAnimateWorkingUnits()) {
    scheduleAnimation();
  }

  maybeAutoAdvanceTurn();
}

function activateMode(nextMode) {
  setInteractionMode(nextMode);
  loadCurrentFileForMode(nextMode);
}

function startNewGeneratedState(mode, buildCells = buildGeneratedMapCells) {
  if (!mode) return false;

  setInteractionMode(mode);
  applyStateSnapshot(createGeneratedState(mode, buildCells), mode);

  if (mode === interactionModes.play) {
    saveStateToFile(autosaveSlotName, interactionModes.play);
    return true;
  }

  writeCurrentFileName(mode, null);
  updatePersistenceControls();
  return true;
}

function getUnitTargetCells() {
  const selectedUnit = getSelectedUnit();

  if (!selectedUnit) return [];

  if (selectedUnit.task && selectedUnit.task.type !== "play") {
    const destinationCell = getCell(selectedUnit.task.toX, selectedUnit.task.toY);
    return destinationCell ? [destinationCell] : [];
  }

  if (selectedUnit.move) {
    return [];
  }

  const action = getCurrentSelectedUnitAction();

  if (action === unitActions.buildHouse) {
    return getBuildableAdjacentCells(selectedUnit);
  }

  if (action === unitActions.demolish) {
    return getDemolishableAdjacentCells(selectedUnit);
  }

  return [];
}

function getUnitTargetStyle() {
  const selectedUnit = getSelectedUnit();
  const action =
    selectedUnit?.task && selectedUnit.task.type !== "play"
      ? getActionForTask(selectedUnit.task)
      : getCurrentSelectedUnitAction();

  if (action === unitActions.demolish) {
    return {
      fill: "rgba(196, 90, 92, 0.2)",
      stroke: "rgba(236, 150, 152, 0.7)",
    };
  }

  if (action === unitActions.buildHouse) {
    return {
      fill: "rgba(209, 182, 99, 0.2)",
      stroke: "rgba(242, 223, 156, 0.74)",
    };
  }

  return {
    fill: "rgba(98, 198, 136, 0.18)",
    stroke: "rgba(152, 236, 185, 0.62)",
  };
}

function isCellVisibleToPlayer(cell) {
  if (!cell) return false;
  if (!isPlayMode()) return true;
  if (cell.visited) return true;

  for (const direction of getMovementDirections()) {
    const neighbor = getNeighborByDirection(cell, direction);

    if (neighbor?.visited) {
      return true;
    }
  }

  return false;
}

function getNeighborByDirection(cell, direction) {
  if (["northWest", "northEast", "southEast", "southWest"].includes(direction)) {
    return getEdgeNeighbor(cell, direction);
  }

  if (["north", "east", "south", "west"].includes(direction)) {
    return getCornerNeighbor(cell, direction);
  }

  return null;
}

function getMovementDirections() {
  return ["north", "northEast", "east", "southEast", "south", "southWest", "west", "northWest"];
}

function getAdjacentCells(cell) {
  if (!cell) return [];

  const neighbors = [];

  for (const direction of getMovementDirections()) {
    const neighbor = getNeighborByDirection(cell, direction);

    if (neighbor) {
      neighbors.push(neighbor);
    }
  }

  return neighbors;
}

function areCellsAdjacent(fromX, fromY, toX, toY) {
  const cell = getCell(fromX, fromY);

  if (!cell) return false;

  return getAdjacentCells(cell).some((neighbor) => neighbor.x === toX && neighbor.y === toY);
}

function canBuildHouseOnCell(cell) {
  return (
    Boolean(cell) &&
    cell.type === "grass" &&
    !getBuildingAtCell(cell.x, cell.y) &&
    !getUnitAtCell(cell.x, cell.y)
  );
}

function getBuildableAdjacentCells(currentUnit = unit) {
  const originCell = currentUnit ? getCell(currentUnit.x, currentUnit.y) : null;

  return getAdjacentCells(originCell).filter((cell) => canBuildHouseOnCell(cell));
}

function getDemolishableAdjacentCells(currentUnit = unit) {
  const originCell = currentUnit ? getCell(currentUnit.x, currentUnit.y) : null;

  return getAdjacentCells(originCell).filter((cell) => {
    const building = getBuildingAtCell(cell.x, cell.y);
    return Boolean(building && building.state === "abandoned");
  });
}

function createCellKey(x, y) {
  return `${x},${y}`;
}

function buildTurnRoutes(currentUnit, cell, destinationCell, remainingStamina, visitedKeys, steps = []) {
  if (!cell || !destinationCell) return [];

  if (steps.length > 0 && cell.x === destinationCell.x && cell.y === destinationCell.y) {
    return [{ steps }];
  }

  if (remainingStamina <= 0) {
    return steps.length > 0 ? [{ steps }] : [];
  }

  const directions = getMovementDirections();
  const routes = [];

  for (const direction of directions) {
    const neighbor = getNeighborByDirection(cell, direction);

    if (!canUnitEnter(neighbor, currentUnit)) continue;
    if (
      steps.length === 0 &&
      neighbor.x === currentUnit.lastStepFromX &&
      neighbor.y === currentUnit.lastStepFromY
    ) {
      continue;
    }

    const neighborKey = createCellKey(neighbor.x, neighbor.y);

    if (visitedKeys.has(neighborKey)) {
      continue;
    }

    const moveCost = getTerrainMoveCost(neighbor);
    const staminaAfterMove = Math.max(0, remainingStamina - moveCost);
    const nextSteps = steps.concat({
      cell: neighbor,
      direction,
      moveCost,
    });
    const nextVisitedKeys = new Set(visitedKeys);
    nextVisitedKeys.add(neighborKey);
    const childRoutes = buildTurnRoutes(
      currentUnit,
      neighbor,
      destinationCell,
      staminaAfterMove,
      nextVisitedKeys,
      nextSteps,
    );

    if (childRoutes.length > 0) {
      routes.push(...childRoutes);
      continue;
    }

    routes.push({ steps: nextSteps });
  }

  return routes;
}

function chooseBestTurnRoute(routes, destinationCell) {
  let bestRoute = null;
  let bestDistance = Number.POSITIVE_INFINITY;
  let bestFirstStepDistance = Number.POSITIVE_INFINITY;
  let bestStepCount = -1;

  for (const route of routes) {
    if (!route?.steps?.length) continue;

    const firstStep = route.steps[0];
    const finalStep = route.steps[route.steps.length - 1];
    const finalDistance = walkingDistance(
      finalStep.cell.x,
      finalStep.cell.y,
      destinationCell.x,
      destinationCell.y,
    );
    const firstStepDistance = walkingDistance(
      firstStep.cell.x,
      firstStep.cell.y,
      destinationCell.x,
      destinationCell.y,
    );

    if (
      finalDistance < bestDistance ||
      (finalDistance === bestDistance && firstStepDistance < bestFirstStepDistance) ||
      (
        finalDistance === bestDistance &&
        firstStepDistance === bestFirstStepDistance &&
        route.steps.length > bestStepCount
      )
    ) {
      bestDistance = finalDistance;
      bestFirstStepDistance = firstStepDistance;
      bestStepCount = route.steps.length;
      bestRoute = route.steps;
    }
  }

  return bestRoute;
}

function getPlannedTurnRoute(currentUnit, task, originCell, destinationCell) {
  if (!currentUnit.turnRoute?.length) {
    const routes = buildTurnRoutes(
      currentUnit,
      originCell,
      destinationCell,
      getUnitStamina(currentUnit),
      new Set([createCellKey(originCell.x, originCell.y)]),
    );
    currentUnit.turnRoute = chooseBestTurnRoute(routes, destinationCell) || null;
  }

  return currentUnit.turnRoute;
}

function getNextMoveStep(currentUnit, task) {
  const originCell = getCell(currentUnit.x, currentUnit.y);
  const destinationCell = getCell(task.toX, task.toY);

  if (!originCell || !destinationCell) return null;

  const route = getPlannedTurnRoute(currentUnit, task, originCell, destinationCell);

  if (!route?.length) return null;

  const [nextStep, ...rest] = route;
  currentUnit.turnRoute = rest.length > 0 ? rest : null;
  return nextStep;
}

function handlePlayModeClick(cell) {
  hideTileMenu();

  const selectedUnit = getSelectedUnit();
  const movingUnit = getMovingUnit();

  if (movingUnit) return;

  if (!cell) {
    clearUnitSelection();
    maybeAutoAdvanceTurn();
    draw();
    return;
  }

  const clickedUnit = getUnitAtCell(cell.x, cell.y);

  if (clickedUnit) {
    const wasSelected = clickedUnit.selected;

    if (wasSelected) {
      clearUnitSelection();
      maybeAutoAdvanceTurn();
      draw();
      return;
    }

    selectUnit(clickedUnit);
    return;
  }

  if (selectedUnit) {
    const action = getCurrentSelectedUnitAction();

    if (action === unitActions.wait) {
      return;
    }

    if (action === unitActions.play) {
      return;
    }

    if (action === unitActions.buildHouse) {
      queueUnitBuildHouseTask(cell, selectedUnit);
      return;
    }

    if (action === unitActions.demolish) {
      queueUnitDemolishTask(cell, selectedUnit);
      return;
    }

    if (canUnitEnter(cell, selectedUnit)) {
      queueUnitMoveTask(cell, selectedUnit);
      return;
    }
  }

  clearUnitSelection();
  maybeAutoAdvanceTurn();
  draw();
}

function startUnitMove(
  destinationCell,
  direction,
  currentUnit = unit,
) {
  if (!currentUnit) return;

  currentUnit.move = {
    fromX: currentUnit.x,
    fromY: currentUnit.y,
    toX: destinationCell.x,
    toY: destinationCell.y,
    direction: direction || getMoveDirection(currentUnit.x, currentUnit.y, destinationCell.x, destinationCell.y),
    startedAt: performance.now(),
  };
  unit = currentUnit;
  invalidateStaticUnitsLayer();
  updateUnitReadout();
  updateTurnControls();
  scheduleAnimation();
  draw();
}

function scheduleAnimation() {
  if (animationFrameId) return;

  animationFrameId = requestAnimationFrame(stepAnimations);
}

function stepAnimations(now) {
  animationFrameId = 0;
  let needsAnotherFrame = shouldAnimateWorkingUnits() || shouldAnimateSelectionMarker();
  const movingUnit = getMovingUnit();

  if (movingUnit?.move) {
    const progress = getUnitMoveProgress(movingUnit, now);

    if (progress >= 1) {
      const moveToX = movingUnit.move.toX;
      const moveToY = movingUnit.move.toY;
      const moveFromX = movingUnit.move.fromX;
      const moveFromY = movingUnit.move.fromY;

      movingUnit.x = movingUnit.move.toX;
      movingUnit.y = movingUnit.move.toY;
      movingUnit.facing = movingUnit.move.direction || movingUnit.facing;
      movingUnit.lastStepFromX = moveFromX;
      movingUnit.lastStepFromY = moveFromY;
      movingUnit.move = null;
      const destinationCell = getCell(movingUnit.x, movingUnit.y);

      if (destinationCell && !destinationCell.visited) {
        destinationCell.visited = true;
        invalidateStaticLayer();
      }

      if (
        movingUnit.task?.type === "move" &&
        movingUnit.task.toX === moveToX &&
        movingUnit.task.toY === moveToY
      ) {
        applyCompletedTaskDefaultAction("move", movingUnit);
        movingUnit.task = null;
        movingUnit.turnRoute = null;
      }

      syncActiveUnit(movingUnit.id);
      invalidateStaticUnitsLayer();
      updateUnitReadout();
      updateTurnControls();

      if (turnResolutionActive) {
        continueTurnResolution();
        return;
      }

      maybeAutoAdvanceTurn();
    } else {
      needsAnotherFrame = true;
    }
  }

  draw(now);

  if (needsAnotherFrame) {
    scheduleAnimation();
  }
}

function getUnitMoveProgress(currentUnit = unit, now = performance.now()) {
  if (!currentUnit?.move) return 1;

  const elapsed = now - currentUnit.move.startedAt;
  return clamp(elapsed / unitSprite.moveDuration, 0, 1);
}

function getUnitScreenPosition(currentUnit = unit, now = performance.now()) {
  if (!currentUnit) return null;
  if (!currentUnit.move) return isoToScreen(currentUnit.x, currentUnit.y);

  const progress = easeInOut(getUnitMoveProgress(currentUnit, now));
  const from = isoToScreen(currentUnit.move.fromX, currentUnit.move.fromY);
  const to = isoToScreen(currentUnit.move.toX, currentUnit.move.toY);

  return {
    x: lerp(from.x, to.x, progress),
    y: lerp(from.y, to.y, progress),
  };
}

function getUnitGroundPoint(screen) {
  return {
    x: screen.x,
    y: screen.y + tile.height * unitSprite.groundOffset,
  };
}

function getMoveDirection(fromX, fromY, toX, toY) {
  const origin = getCell(fromX, fromY);

  if (!origin) return "west";

  for (const direction of ["northWest", "northEast", "southEast", "southWest"]) {
    const neighbor = getEdgeNeighbor(origin, direction);

    if (neighbor && neighbor.x === toX && neighbor.y === toY) {
      return direction;
    }
  }

  for (const direction of ["north", "east", "south", "west"]) {
    const neighbor = getCornerNeighbor(origin, direction);

    if (neighbor && neighbor.x === toX && neighbor.y === toY) {
      return direction;
    }
  }

  return "west";
}

function shouldMirrorUnitDirection(direction) {
  return direction === "east" || direction === "northEast" || direction === "southEast";
}

function usesNorthUnitSprite(direction) {
  return direction === "north";
}

function usesSouthUnitSprite(direction) {
  return direction === "south";
}

function getStationaryUnits() {
  if (interactionMode !== interactionModes.play) {
    return [];
  }

  return getUnits().filter((currentUnit) => currentUnit && !currentUnit.move && !currentUnit.selected);
}

function getMovingUnit() {
  return getUnits().find((currentUnit) => currentUnit?.move) || null;
}

function compareUnitsByDrawOrder(a, b) {
  if (a.y !== b.y) return a.y - b.y;
  return a.x - b.x;
}

function compareBuildingsByDrawOrder(a, b) {
  const aRow = a.y + a.height - 1;
  const bRow = b.y + b.height - 1;

  if (aRow !== bRow) return aRow - bRow;
  return a.x - b.x;
}

function drawUnitTargets() {
  if (interactionMode !== interactionModes.play || !getSelectedUnit()) {
    return;
  }

  const style = getUnitTargetStyle();

  for (const cell of getUnitTargetCells()) {
    const screen = isoToScreen(cell.x, cell.y);
    drawDiamondPath(screen.x, screen.y);
    ctx.fillStyle = style.fill;
    ctx.fill();
    ctx.strokeStyle = style.stroke;
    ctx.lineWidth = 1.6;
    ctx.stroke();
  }
}

function drawUnitMoveTaskLines(now = performance.now()) {
  if (interactionMode !== interactionModes.play) {
    return;
  }

  const movingUnits = getUnits().filter(
    (currentUnit) =>
      currentUnit?.task?.type === "move" &&
      (currentUnit.task.toX !== currentUnit.x || currentUnit.task.toY !== currentUnit.y),
  );

  if (movingUnits.length === 0) {
    return;
  }

  ctx.save();
  ctx.setLineDash([8, 6]);
  ctx.lineCap = "round";
  ctx.lineJoin = "round";

  for (const currentUnit of movingUnits) {
    const fromScreen = getUnitScreenPosition(currentUnit, now);
    const destinationCell = getCell(currentUnit.task.toX, currentUnit.task.toY);

    if (!fromScreen || !destinationCell) {
      continue;
    }

    const fromGround = getUnitGroundPoint(fromScreen);
    const toScreen = isoToScreen(destinationCell.x, destinationCell.y);
    const toPoint = {
      x: toScreen.x,
      y: toScreen.y + tile.height * 0.52,
    };

    ctx.strokeStyle = "rgba(18, 22, 20, 0.45)";
    ctx.lineWidth = Math.max(2.5, 3 * zoomLevels[zoomIndex]);
    ctx.beginPath();
    ctx.moveTo(fromGround.x, fromGround.y);
    ctx.lineTo(toPoint.x, toPoint.y);
    ctx.stroke();

    ctx.strokeStyle = "rgba(239, 224, 170, 0.8)";
    ctx.lineWidth = Math.max(1.2, 1.5 * zoomLevels[zoomIndex]);
    ctx.beginPath();
    ctx.moveTo(fromGround.x, fromGround.y);
    ctx.lineTo(toPoint.x, toPoint.y);
    ctx.stroke();
  }

  ctx.restore();
}

function drawSelectedUnitMarker() {
  const selectedUnit = getSelectedUnit();

  if (interactionMode !== interactionModes.play || !selectedUnit) return;

  const screen = getUnitScreenPosition(selectedUnit);

  if (!screen) return;

  const now = performance.now();
  const pulse = (Math.sin(now / 320) + 1) / 2;
  const centerY = screen.y + tile.height * 0.66;
  const radiusX = tile.width * (0.29 + pulse * 0.05);
  const radiusY = tile.height * (0.112 + pulse * 0.02);
  const fillAlpha = 0.5 + pulse * 0.22;

  ctx.save();
  ctx.fillStyle = `rgba(68, 98, 178, ${fillAlpha})`;
  ctx.beginPath();
  ctx.ellipse(
    screen.x,
    centerY,
    radiusX,
    radiusY,
    0,
    0,
    Math.PI * 2,
  );
  ctx.fill();

  ctx.strokeStyle = "rgb(102, 171, 255)";
  ctx.lineWidth = Math.max(1.5, 2 * zoomLevels[zoomIndex]);
  ctx.beginPath();
  ctx.ellipse(
    screen.x,
    centerY,
    radiusX,
    radiusY,
    0,
    0,
    Math.PI * 2,
  );
  ctx.stroke();

  ctx.restore();
}

function drawMovingUnit(now = performance.now()) {
  if (interactionMode !== interactionModes.play) return;

  const movingUnit = getMovingUnit();

  if (!movingUnit) return;

  const screen = getUnitScreenPosition(movingUnit, now);
  const direction = movingUnit.move?.direction || movingUnit.facing || "west";
  const imagePath = getMovingUnitImage(movingUnit, direction, now);

  if (!screen) return;

  drawUnitAtScreen(screen, ctx, imagePath, shouldMirrorUnitDirection(direction), !movingUnit.selected);
}

function drawSelectedStationaryUnit(now = performance.now()) {
  const selectedUnit = getSelectedUnit();

  if (interactionMode !== interactionModes.play || !selectedUnit || selectedUnit.move) {
    return;
  }

  const direction = getUnitDisplayDirection(selectedUnit);

  drawUnitAtScreen(
    isoToScreen(selectedUnit.x, selectedUnit.y),
    ctx,
    getStationaryUnitImage(selectedUnit, now),
    shouldMirrorUnitDirection(direction),
    false,
  );
}

function drawStationaryUnits(drawContext = ctx, frameIndex = 0) {
  const stationaryUnits = getStationaryUnits().slice().sort(compareUnitsByDrawOrder);

  for (const stationaryUnit of stationaryUnits) {
    const direction = getUnitDisplayDirection(stationaryUnit);
    drawUnitAtScreen(
      isoToScreen(stationaryUnit.x, stationaryUnit.y),
      drawContext,
      getStationaryUnitImage(stationaryUnit, undefined, frameIndex),
      shouldMirrorUnitDirection(direction),
      !stationaryUnit.selected,
    );
  }
}

function getUnitDisplayDirection(currentUnit) {
  if (isUnitWorking(currentUnit)) {
    return getUnitTaskDirection(currentUnit);
  }

  return currentUnit?.facing || "west";
}

function getWorkingUnitImage(frameIndex = 0) {
  if (unitSprite.workFrames.length === 0) {
    return unitSprite.idleImage;
  }

  return unitSprite.workFrames[frameIndex % unitSprite.workFrames.length] || unitSprite.idleImage;
}

function getAnimatedTaskFrameOffset(currentUnit) {
  if (!currentUnit) {
    return 0;
  }

  if (!Number.isInteger(currentUnit.animatedTaskFrameOffset)) {
    currentUnit.animatedTaskFrameOffset = Math.random() < 0.5 ? 1 : 0;
  }

  return currentUnit.animatedTaskFrameOffset;
}

function getAnimatedTaskUnitImage(currentUnit, frameIndex = 0) {
  const frames =
    currentUnit?.task?.type === "play" && unitSprite.playFrames.length > 0
      ? unitSprite.playFrames
      : unitSprite.workFrames;

  if (frames.length === 0) {
    return unitSprite.idleImage;
  }

  const offsetFrameIndex = frameIndex + getAnimatedTaskFrameOffset(currentUnit);

  return frames[offsetFrameIndex % frames.length] || unitSprite.idleImage;
}

function getStationaryUnitImage(currentUnit, now = performance.now(), explicitFrameIndex = null) {
  if (isUnitWorking(currentUnit)) {
    const frameIndex =
      explicitFrameIndex === null ? getWorkingUnitFrameIndex(now) : explicitFrameIndex;

    return getAnimatedTaskUnitImage(currentUnit, frameIndex);
  }

  const direction = getUnitDisplayDirection(currentUnit);

  if (usesNorthUnitSprite(direction)) {
    return unitSprite.northImage;
  }

  if (usesSouthUnitSprite(direction)) {
    return unitSprite.southImage;
  }

  return unitSprite.idleImage;
}

function getMovingUnitImage(currentUnit = unit, direction = "west", now = performance.now()) {
  let moveFrames = unitSprite.moveFrames;
  let fallbackImage = unitSprite.idleImage;

  if (usesNorthUnitSprite(direction)) {
    moveFrames = unitSprite.northMoveFrames;
    fallbackImage = unitSprite.northImage;
  } else if (usesSouthUnitSprite(direction)) {
    moveFrames = unitSprite.southMoveFrames;
    fallbackImage = unitSprite.southImage;
  }

  if (
    !currentUnit?.move ||
    moveFrames.length === 0 ||
    unitSprite.moveFrameSequence.length === 0
  ) {
    return fallbackImage;
  }

  const progress = getUnitMoveProgress(currentUnit, now);
  const phaseIndex = Math.min(
    unitSprite.moveFrameSequence.length - 1,
    Math.floor(progress * unitSprite.moveFrameSequence.length),
  );
  const frameIndex = unitSprite.moveFrameSequence[phaseIndex];

  return moveFrames[frameIndex] || fallbackImage;
}

function drawUnitAtScreen(
  screen,
  drawContext = ctx,
  imagePath = unitSprite.idleImage,
  mirrorX = false,
  showShadow = true,
) {
  const image = unitImages[imagePath];
  const drawWidth = unitSprite.width * zoomLevels[zoomIndex];
  const drawHeight = unitSprite.height * zoomLevels[zoomIndex];
  const drawX = screen.x - unitSprite.anchorX * zoomLevels[zoomIndex];
  const ground = getUnitGroundPoint(screen);
  const groundY = ground.y;
  const drawY = groundY - unitSprite.anchorY * zoomLevels[zoomIndex];

  drawContext.save();
  if (showShadow) {
    drawContext.fillStyle = "rgba(5, 8, 10, 0.28)";
    drawContext.beginPath();
    drawContext.ellipse(
      screen.x,
      groundY + 2 * zoomLevels[zoomIndex],
      tile.width * 0.15,
      tile.height * 0.08,
      0,
      0,
      Math.PI * 2,
    );
    drawContext.fill();
  }

  if (image?.complete && image.naturalWidth > 0) {
    if (mirrorX) {
      drawContext.translate(drawX + drawWidth, drawY);
      drawContext.scale(-1, 1);
      drawContext.drawImage(image, 0, 0, drawWidth, drawHeight);
    } else {
      drawContext.drawImage(image, drawX, drawY, drawWidth, drawHeight);
    }
  } else {
    drawContext.fillStyle = "#d7b45b";
    drawContext.beginPath();
    drawContext.arc(
      screen.x,
      groundY - tile.height * 0.32,
      tile.width * 0.12,
      0,
      Math.PI * 2,
    );
    drawContext.fill();
  }

  drawContext.restore();
}

function easeInOut(t) {
  return t < 0.5 ? 2 * t * t : 1 - ((-2 * t + 2) ** 2) / 2;
}

function resizeCanvas() {
  layoutCanvas();
}

function layoutCanvas({ preserveCenter = false } = {}) {
  const dpr = window.devicePixelRatio || 1;
  const center = preserveCenter ? getViewportCenterRatio() : null;

  applyZoom();

  const canvasSize = getCanvasSize();
  const mapPixelSize = getMapPixelSize();
  const leftInset = Math.max(canvasPadding, (canvasSize.width - mapPixelSize.width) / 2);
  const topInset = Math.max(canvasPadding, (canvasSize.height - mapPixelSize.height) / 2);

  canvas.style.width = `${canvasSize.width}px`;
  canvas.style.height = `${canvasSize.height}px`;
  canvas.width = Math.round(canvasSize.width * dpr);
  canvas.height = Math.round(canvasSize.height * dpr);
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  currentDpr = dpr;

  origin = {
    x: leftInset + tile.width / 2,
    y: topInset,
  };

  invalidateStaticLayer();
  invalidateStaticUnitsLayer();
  draw();
  updateZoomControls();

  if (center) {
    requestAnimationFrame(() => restoreViewportCenter(center));
  } else if (!didCenterInitialView) {
    requestAnimationFrame(centerInitialView);
  }
}

function applyZoom() {
  const zoom = zoomLevels[zoomIndex];
  tile.width = baseTile.width * zoom;
  tile.height = baseTile.height * zoom;
  tile.edge = baseTile.edge * zoom;
}

function getCanvasSize() {
  const mapPixelSize = getMapPixelSize();

  return {
    width: Math.ceil(
      Math.max(
        mapPixelSize.width + canvasPadding * 2,
        viewport.clientWidth + canvasPadding * 2,
      ),
    ),
    height: Math.ceil(
      Math.max(
        mapPixelSize.height + canvasPadding * 2,
        viewport.clientHeight + canvasPadding * 2,
      ),
    ),
  };
}

function getMapPixelSize() {
  const hasOffsetRows = map.height > 1;

  return {
    width: map.width * tile.width + (hasOffsetRows ? tile.width / 2 : 0),
    height: (map.height - 1) * (tile.height / 2) + tile.height + tile.edge,
  };
}

function distance(x1, y1, x2, y2) {
  return Math.hypot(x1 - x2, y1 - y2);
}

function walkingDistance(x1, y1, x2, y2) {
  const u1 = x1 + Math.ceil(y1 / 2);
  const v1 = x1 - Math.floor(y1 / 2);
  const u2 = x2 + Math.ceil(y2 / 2);
  const v2 = x2 - Math.floor(y2 / 2);

  return Math.max(Math.abs(u1 - u2), Math.abs(v1 - v2));
}

function isoToScreen(x, y) {
  return {
    x: origin.x + x * tile.width + (y % 2) * (tile.width / 2),
    y: origin.y + y * (tile.height / 2),
  };
}

function drawDiamondPath(cx, cy, lift = 0) {
  const halfW = tile.width / 2;
  const halfH = tile.height / 2;
  const topY = cy - lift;

  ctx.beginPath();
  ctx.moveTo(cx, topY);
  ctx.lineTo(cx + halfW, topY + halfH);
  ctx.lineTo(cx, topY + tile.height);
  ctx.lineTo(cx - halfW, topY + halfH);
  ctx.closePath();
}

function drawTile(cell) {
  if (!isCellVisibleToPlayer(cell)) {
    return;
  }

  const screen = isoToScreen(cell.x, cell.y);
  const spec = terrain[cell.type];
  const lift = 0;

  drawTileBase(cell, screen, lift, spec);
  drawTerrainTransitions(cell, screen, lift);
  drawFogBorders(cell, screen, lift);
  recordTileHitArea(cell, screen, lift);
}

function recordTileHitArea(cell, screen, lift) {
  drawList.push({
    cell,
    points: [
      { x: screen.x, y: screen.y - lift },
      { x: screen.x + tile.width / 2, y: screen.y + tile.height / 2 - lift },
      { x: screen.x, y: screen.y + tile.height - lift },
      { x: screen.x - tile.width / 2, y: screen.y + tile.height / 2 - lift },
    ],
  });
}

function drawInteractiveTileOverlays() {
  if (!isEditMode()) return;

  if (hoverCell) {
    drawTileOverlay(hoverCell, {
      fillStyle: "rgba(255, 239, 158, 0.28)",
      strokeStyle: "#ffe886",
      lineWidth: 2,
    });
  }

  if (activeCell) {
    drawTileOverlay(activeCell, {
      fillStyle: "rgba(215, 180, 91, 0.16)",
      strokeStyle: "#d7b45b",
      lineWidth: 2.5,
    });
  }
}

function drawTileOverlay(cell, style) {
  if (!cell) return;

  const screen = isoToScreen(cell.x, cell.y);

  drawDiamondPath(screen.x, screen.y);
  ctx.fillStyle = style.fillStyle;
  ctx.fill();
  ctx.strokeStyle = style.strokeStyle;
  ctx.lineWidth = style.lineWidth;
  ctx.stroke();
}

function drawTileBase(cell, screen, lift, spec) {
  const variantId = ensureCellVariant(cell);
  const variant = getTerrainVariant(cell.type, variantId);
  const image = variant ? tileImages[variant.image] : null;

  if (image?.complete && image.naturalWidth > 0) {
    ctx.drawImage(
      image,
      screen.x - tile.width / 2,
      screen.y - lift,
      tile.width,
      tile.height + tile.edge,
    );
    return;
  }

  drawProceduralTile(cell, screen, lift, spec);
}

function drawBuildings() {
  const visibleBuildings = buildings
    .filter((building) => isCellVisibleToPlayer(getCell(building.x, building.y)))
    .slice()
    .sort(compareBuildingsByDrawOrder);

  for (const building of visibleBuildings) {
    drawBuilding(building);
  }
}

function drawBuilding(building) {
  const visual = getBuildingVisual(building);

  if (!visual?.image) return;

  const image = buildingImages[visual.image];

  if (!image?.complete || image.naturalWidth <= 0) return;

  const screen = isoToScreen(building.x, building.y);
  const drawY =
    screen.y - tile.edge - tile.height * 0.32 + tile.height * (visual.yOffsetFactor || 0);

  ctx.save();
  ctx.globalAlpha = visual.alpha ?? 1;
  ctx.drawImage(
    image,
    screen.x - tile.width / 2,
    drawY,
    tile.width,
    tile.height + tile.edge,
  );
  ctx.restore();
}

function drawFogBorders(cell, screen, lift) {
  if (!isPlayMode()) return;

  ctx.save();
  ctx.strokeStyle = "rgba(9, 12, 11, 0.52)";
  ctx.lineWidth = Math.max(10, tile.width * 0.19);
  ctx.lineCap = "round";

  for (const edge of getTileEdges(screen, lift)) {
    const neighbor = getEdgeNeighbor(cell, edge.direction);

    if (!neighbor || isCellVisibleToPlayer(neighbor)) continue;

    ctx.beginPath();
    ctx.moveTo(edge.start.x, edge.start.y);
    ctx.lineTo(edge.end.x, edge.end.y);
    ctx.stroke();
  }

  ctx.restore();
}

function drawProceduralTile(cell, screen, lift, spec) {
  const left = screen.x - tile.width / 2;
  const right = screen.x + tile.width / 2;
  const midY = screen.y + tile.height / 2 - lift;
  const bottomY = screen.y + tile.height + tile.edge;

  ctx.beginPath();
  ctx.moveTo(screen.x - tile.width / 2, midY);
  ctx.lineTo(screen.x, screen.y + tile.height - lift);
  ctx.lineTo(screen.x, bottomY);
  ctx.lineTo(left, midY + tile.edge);
  ctx.closePath();
  ctx.fillStyle = shade(spec.side, -18);
  ctx.fill();

  ctx.beginPath();
  ctx.moveTo(screen.x + tile.width / 2, midY);
  ctx.lineTo(screen.x, screen.y + tile.height - lift);
  ctx.lineTo(screen.x, bottomY);
  ctx.lineTo(right, midY + tile.edge);
  ctx.closePath();
  ctx.fillStyle = spec.side;
  ctx.fill();

  drawDiamondPath(screen.x, screen.y, lift);
  ctx.fillStyle = spec.top;
  ctx.fill();
  ctx.strokeStyle = spec.stroke;
  ctx.lineWidth = 1;
  ctx.stroke();

  drawTerrainDetails(cell, screen, lift, spec);
}

function drawTerrainDetails(cell, screen, lift, spec) {
  const detailScale = tile.width / baseTile.width;
  const cx = screen.x;
  const cy = screen.y - lift;

  if (cell.type === "water") {
    ctx.strokeStyle = spec.detail;
    ctx.lineWidth = Math.max(1, 1.4 * detailScale);
    ctx.globalAlpha = 0.7;
    drawWave(cx - 18 * detailScale, cy + 20 * detailScale, 16 * detailScale);
    drawWave(cx + 4 * detailScale, cy + 29 * detailScale, 20 * detailScale);
    ctx.globalAlpha = 1;
    return;
  }

  if (cell.type === "forest") {
    drawTree(cx - 16 * detailScale, cy + 28 * detailScale, detailScale);
    drawTree(cx + 3 * detailScale, cy + 20 * detailScale, detailScale);
    drawTree(cx + 17 * detailScale, cy + 32 * detailScale, detailScale);
    return;
  }

  if (cell.type === "mountain") {
    ctx.strokeStyle = spec.detail;
    ctx.lineWidth = Math.max(1, 2 * detailScale);
    ctx.beginPath();
    ctx.moveTo(cx - 20 * detailScale, cy + 27 * detailScale);
    ctx.quadraticCurveTo(
      cx - 4 * detailScale,
      cy + 15 * detailScale,
      cx + 15 * detailScale,
      cy + 27 * detailScale,
    );
    ctx.stroke();
    ctx.lineWidth = Math.max(1, detailScale);
    ctx.beginPath();
    ctx.moveTo(cx - 12 * detailScale, cy + 36 * detailScale);
    ctx.quadraticCurveTo(
      cx + 5 * detailScale,
      cy + 27 * detailScale,
      cx + 25 * detailScale,
      cy + 36 * detailScale,
    );
    ctx.stroke();
    return;
  }

  ctx.strokeStyle = spec.detail;
  ctx.lineWidth = Math.max(1, 1.5 * detailScale);
  ctx.globalAlpha = 0.55;
  ctx.beginPath();
  ctx.moveTo(cx - 20 * detailScale, cy + 26 * detailScale);
  ctx.lineTo(cx - 12 * detailScale, cy + 23 * detailScale);
  ctx.moveTo(cx + 12 * detailScale, cy + 34 * detailScale);
  ctx.lineTo(cx + 22 * detailScale, cy + 30 * detailScale);
  ctx.stroke();
  ctx.globalAlpha = 1;
}

function drawTerrainTransitions(cell, screen, lift) {
  for (const rule of transitionRules) {
    if (cell.type !== rule.baseType) continue;

    const edges = getTileEdges(screen, lift);

    for (const edge of edges) {
      const neighbor = getEdgeNeighbor(cell, edge.direction);

      if (!neighbor || !rule.neighborTypes.includes(neighbor.type)) continue;

      if (rule.drawEdge) {
        rule.drawEdge(edge, screen, lift);
      }
    }

    if (rule.drawCorner) {
      for (const corner of getTileCorners(screen, lift)) {
        if (!shouldDrawCornerTransition(rule, cell, corner)) continue;

        rule.drawCorner(corner, screen, lift);
      }
    }
  }
}

function getTileEdges(screen, lift) {
  const top = { x: screen.x, y: screen.y - lift };
  const right = {
    x: screen.x + tile.width / 2,
    y: screen.y + tile.height / 2 - lift,
  };
  const bottom = { x: screen.x, y: screen.y + tile.height - lift };
  const left = {
    x: screen.x - tile.width / 2,
    y: screen.y + tile.height / 2 - lift,
  };

  return [
    { direction: "northWest", start: top, end: left },
    { direction: "northEast", start: top, end: right },
    { direction: "southEast", start: right, end: bottom },
    { direction: "southWest", start: left, end: bottom },
  ];
}

function getTileCorners(screen, lift) {
  const top = { x: screen.x, y: screen.y - lift };
  const right = {
    x: screen.x + tile.width / 2,
    y: screen.y + tile.height / 2 - lift,
  };
  const bottom = { x: screen.x, y: screen.y + tile.height - lift };
  const left = {
    x: screen.x - tile.width / 2,
    y: screen.y + tile.height / 2 - lift,
  };

  return [
    {
      direction: "north",
      point: top,
      edgePoints: [left, right],
      edgeDirections: ["northWest", "northEast"],
    },
    {
      direction: "east",
      point: right,
      edgePoints: [top, bottom],
      edgeDirections: ["northEast", "southEast"],
    },
    {
      direction: "south",
      point: bottom,
      edgePoints: [right, left],
      edgeDirections: ["southEast", "southWest"],
    },
    {
      direction: "west",
      point: left,
      edgePoints: [bottom, top],
      edgeDirections: ["southWest", "northWest"],
    },
  ];
}

function getEdgeNeighbor(cell, direction) {
  const isOddRow = cell.y % 2 === 1;
  const offsets = {
    northWest: { x: isOddRow ? 0 : -1, y: -1 },
    northEast: { x: isOddRow ? 1 : 0, y: -1 },
    southEast: { x: isOddRow ? 1 : 0, y: 1 },
    southWest: { x: isOddRow ? 0 : -1, y: 1 },
  };
  const offset = offsets[direction];

  return getCell(cell.x + offset.x, cell.y + offset.y);
}

function getCornerNeighbor(cell, direction) {
  const offsets = {
    north: { x: 0, y: -2 },
    east: { x: 1, y: 0 },
    south: { x: 0, y: 2 },
    west: { x: -1, y: 0 },
  };
  const offset = offsets[direction];

  return getCell(cell.x + offset.x, cell.y + offset.y);
}

function getCell(x, y) {
  if (y < 0 || y >= map.height || x < 0 || x >= map.width) return null;

  return map.cells[y][x];
}

function shouldDrawCornerTransition(rule, cell, corner) {
  const cornerNeighbor = getCornerNeighbor(cell, corner.direction);

  if (!cornerNeighbor || !rule.neighborTypes.includes(cornerNeighbor.type)) {
    return false;
  }

  return corner.edgeDirections.every((edgeDirection) => {
    const edgeNeighbor = getEdgeNeighbor(cell, edgeDirection);

    return edgeNeighbor && edgeNeighbor.type === rule.baseType;
  });
}

function drawShoreEdge(edge, screen, lift) {
  if (drawShoreOverlay(shoreOverlays.edge[edge.direction], screen, lift)) return;

  drawProceduralShoreEdge(edge, screen, lift);
}

function drawProceduralShoreEdge(edge, screen, lift) {
  const scale = tile.width / baseTile.width;
  const shoreWidth = 10 * scale;
  const edgeMidpoint = {
    x: (edge.start.x + edge.end.x) / 2,
    y: (edge.start.y + edge.end.y) / 2,
  };
  const tileCenter = {
    x: screen.x,
    y: screen.y + tile.height / 2 - lift,
  };
  const inward = normalizeVector({
    x: tileCenter.x - edgeMidpoint.x,
    y: tileCenter.y - edgeMidpoint.y,
  });
  const innerStart = {
    x: edge.start.x + inward.x * shoreWidth,
    y: edge.start.y + inward.y * shoreWidth,
  };
  const innerEnd = {
    x: edge.end.x + inward.x * shoreWidth,
    y: edge.end.y + inward.y * shoreWidth,
  };

  ctx.save();
  ctx.beginPath();
  ctx.moveTo(edge.start.x, edge.start.y);
  ctx.lineTo(edge.end.x, edge.end.y);
  ctx.lineTo(innerEnd.x, innerEnd.y);
  ctx.lineTo(innerStart.x, innerStart.y);
  ctx.closePath();
  ctx.fillStyle = "rgba(208, 190, 127, 0.9)";
  ctx.fill();

  ctx.strokeStyle = "rgba(245, 239, 198, 0.7)";
  ctx.lineWidth = Math.max(1, 1.2 * scale);
  ctx.beginPath();
  ctx.moveTo(innerStart.x, innerStart.y);
  ctx.lineTo(innerEnd.x, innerEnd.y);
  ctx.stroke();
  ctx.restore();
}

function drawShoreCorner(corner, screen, lift) {
  if (drawShoreOverlay(shoreOverlays.corner[corner.direction], screen, lift)) return;

  drawProceduralShoreCorner(corner, screen, lift);
}

function drawShoreOverlay(imagePath, screen, lift) {
  const image = shoreOverlayImages[imagePath];

  if (!image?.complete || image.naturalWidth <= 0) return false;

  ctx.drawImage(
    image,
    screen.x - tile.width / 2,
    screen.y - lift,
    tile.width,
    tile.height + tile.edge,
  );

  return true;
}

function drawProceduralShoreCorner(corner, screen, lift) {
  const scale = tile.width / baseTile.width;
  const shoreLength = 15 * scale;
  const shoreDepth = 10 * scale;
  const tileCenter = {
    x: screen.x,
    y: screen.y + tile.height / 2 - lift,
  };
  const edgePointA = pointOnSegment(corner.point, corner.edgePoints[0], shoreLength);
  const edgePointB = pointOnSegment(corner.point, corner.edgePoints[1], shoreLength);
  const innerPoint = pointOnSegment(corner.point, tileCenter, shoreDepth);

  ctx.save();
  ctx.beginPath();
  ctx.moveTo(corner.point.x, corner.point.y);
  ctx.lineTo(edgePointA.x, edgePointA.y);
  ctx.quadraticCurveTo(innerPoint.x, innerPoint.y, edgePointB.x, edgePointB.y);
  ctx.closePath();
  ctx.fillStyle = "rgba(208, 190, 127, 0.9)";
  ctx.fill();

  ctx.strokeStyle = "rgba(245, 239, 198, 0.7)";
  ctx.lineWidth = Math.max(1, 1.2 * scale);
  ctx.beginPath();
  ctx.moveTo(edgePointA.x, edgePointA.y);
  ctx.quadraticCurveTo(innerPoint.x, innerPoint.y, edgePointB.x, edgePointB.y);
  ctx.stroke();
  ctx.restore();
}

function pointOnSegment(start, end, distanceFromStart) {
  const direction = normalizeVector({
    x: end.x - start.x,
    y: end.y - start.y,
  });

  return {
    x: start.x + direction.x * distanceFromStart,
    y: start.y + direction.y * distanceFromStart,
  };
}

function normalizeVector(vector) {
  const length = Math.hypot(vector.x, vector.y) || 1;

  return {
    x: vector.x / length,
    y: vector.y / length,
  };
}

function drawWave(x, y, width) {
  ctx.beginPath();
  ctx.moveTo(x, y);
  ctx.quadraticCurveTo(x + width * 0.25, y - 4, x + width * 0.5, y);
  ctx.quadraticCurveTo(x + width * 0.75, y + 4, x + width, y);
  ctx.stroke();
}

function drawTree(x, y, scale) {
  ctx.fillStyle = "#2a5032";
  ctx.beginPath();
  ctx.moveTo(x, y - 12 * scale);
  ctx.lineTo(x + 11 * scale, y + 9 * scale);
  ctx.lineTo(x - 11 * scale, y + 9 * scale);
  ctx.closePath();
  ctx.fill();

  ctx.fillStyle = "#5b4330";
  ctx.fillRect(x - 2 * scale, y + 7 * scale, 4 * scale, 8 * scale);
}

function shade(hex, amount) {
  const value = Number.parseInt(hex.slice(1), 16);
  const r = clamp((value >> 16) + amount, 0, 255);
  const g = clamp(((value >> 8) & 255) + amount, 0, 255);
  const b = clamp((value & 255) + amount, 0, 255);
  return `rgb(${r}, ${g}, ${b})`;
}

function lerp(a, b, t) {
  return a + (b - a) * t;
}

function clamp(value, min, max) {
  return Math.min(max, Math.max(min, value));
}

function invalidateStaticLayer() {
  staticLayerDirty = true;
}

function invalidateStaticUnitsLayer() {
  staticUnitsLayerDirty = true;
}

function ensureStaticLayerSize() {
  if (staticLayerCanvas.width === canvas.width && staticLayerCanvas.height === canvas.height) {
    return;
  }

  staticLayerCanvas.width = canvas.width;
  staticLayerCanvas.height = canvas.height;
  staticLayerDirty = true;
}

function ensureStaticUnitsLayerSize() {
  const sizesMatch = staticUnitsLayerCanvases.every(
    (layerCanvas) => layerCanvas.width === canvas.width && layerCanvas.height === canvas.height,
  );

  if (sizesMatch) {
    return;
  }

  for (const layerCanvas of staticUnitsLayerCanvases) {
    layerCanvas.width = canvas.width;
    layerCanvas.height = canvas.height;
  }

  staticUnitsLayerDirty = true;
}

function clearMainCanvas() {
  ctx.save();
  ctx.setTransform(1, 0, 0, 1, 0, 0);
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  ctx.restore();
}

function renderStaticLayerToMain() {
  clearMainCanvas();
  drawList = [];

  for (let y = 0; y < map.height; y += 1) {
    for (let x = 0; x < map.width; x += 1) {
      drawTile(map.cells[y][x]);
    }
  }

  drawBuildings();
}

function cacheStaticLayer() {
  ensureStaticLayerSize();
  staticLayerCtx.setTransform(1, 0, 0, 1, 0, 0);
  staticLayerCtx.clearRect(0, 0, staticLayerCanvas.width, staticLayerCanvas.height);
  staticLayerCtx.drawImage(canvas, 0, 0);
  staticLayerDirty = false;
}

function renderStaticUnitsLayer() {
  ensureStaticUnitsLayerSize();

  for (let frameIndex = 0; frameIndex < staticUnitsLayerCanvases.length; frameIndex += 1) {
    const layerCanvas = staticUnitsLayerCanvases[frameIndex];
    const layerContext = staticUnitsLayerContexts[frameIndex];

    layerContext.setTransform(1, 0, 0, 1, 0, 0);
    layerContext.clearRect(0, 0, layerCanvas.width, layerCanvas.height);
    layerContext.setTransform(currentDpr, 0, 0, currentDpr, 0, 0);
    drawStationaryUnits(layerContext, frameIndex);
  }

  staticUnitsLayerDirty = false;
}

function restoreStaticLayerToMain() {
  clearMainCanvas();
  ctx.save();
  ctx.setTransform(1, 0, 0, 1, 0, 0);
  ctx.drawImage(staticLayerCanvas, 0, 0);
  ctx.restore();
}

function restoreStaticUnitsLayerToMain(frameIndex = 0) {
  const layerCanvas = staticUnitsLayerCanvases[frameIndex % staticUnitsLayerCanvases.length];

  ctx.save();
  ctx.setTransform(1, 0, 0, 1, 0, 0);
  ctx.drawImage(layerCanvas, 0, 0);
  ctx.restore();
}

function drawDynamicLayer(now = performance.now()) {
  drawInteractiveTileOverlays();

  if (interactionMode === interactionModes.play) {
    restoreStaticUnitsLayerToMain(getWorkingUnitFrameIndex(now));
    drawUnitMoveTaskLines(now);
    drawSelectedUnitMarker();
    drawUnitTargets();
    drawSelectedStationaryUnit(now);
    drawMovingUnit(now);
  }
}

function draw(now = performance.now()) {
  ensureStaticLayerSize();
  ensureStaticUnitsLayerSize();

  if (staticLayerDirty) {
    renderStaticLayerToMain();
    cacheStaticLayer();
  } else {
    restoreStaticLayerToMain();
  }

  if (staticUnitsLayerDirty) {
    renderStaticUnitsLayer();
  }

  drawDynamicLayer(now);
}

function pointInPolygon(point, polygon) {
  let inside = false;

  for (let i = 0, j = polygon.length - 1; i < polygon.length; j = i, i += 1) {
    const xi = polygon[i].x;
    const yi = polygon[i].y;
    const xj = polygon[j].x;
    const yj = polygon[j].y;
    const intersects =
      yi > point.y !== yj > point.y &&
      point.x < ((xj - xi) * (point.y - yi)) / (yj - yi) + xi;

    if (intersects) inside = !inside;
  }

  return inside;
}

function pickTile(clientX, clientY) {
  const rect = canvas.getBoundingClientRect();
  const point = {
    x: clientX - rect.left,
    y: clientY - rect.top,
  };

  for (let i = drawList.length - 1; i >= 0; i -= 1) {
    const candidate = drawList[i];
    if (pointInPolygon(point, candidate.points)) {
      return candidate.cell;
    }
  }

  return null;
}

function centerInitialView() {
  restoreViewportCenter({ x: 0.5, y: 0.5 });
  didCenterInitialView = true;
}

function getViewportCenterRatio() {
  return {
    x: (viewport.scrollLeft + viewport.clientWidth / 2) / Math.max(1, canvas.offsetWidth),
    y: (viewport.scrollTop + viewport.clientHeight / 2) / Math.max(1, canvas.offsetHeight),
  };
}

function restoreViewportCenter(center) {
  const maxLeft = Math.max(0, canvas.offsetWidth - viewport.clientWidth);
  const maxTop = Math.max(0, canvas.offsetHeight - viewport.clientHeight);

  viewport.scrollLeft = clamp(
    canvas.offsetWidth * center.x - viewport.clientWidth / 2,
    0,
    maxLeft,
  );
  viewport.scrollTop = clamp(
    canvas.offsetHeight * center.y - viewport.clientHeight / 2,
    0,
    maxTop,
  );
}

function centerViewportOnUnit(currentUnit) {
  if (!currentUnit) return;

  const screen = getUnitScreenPosition(currentUnit);

  if (!screen) return;

  const maxLeft = Math.max(0, canvas.offsetWidth - viewport.clientWidth);
  const maxTop = Math.max(0, canvas.offsetHeight - viewport.clientHeight);

  viewport.scrollLeft = clamp(screen.x - viewport.clientWidth / 2, 0, maxLeft);
  viewport.scrollTop = clamp(screen.y + tile.height / 2 - viewport.clientHeight / 2, 0, maxTop);
}

function updateZoomControls() {
  setTextContent(
    zoomLevelReadouts,
    strings.readouts.zoomLevel(Math.round(zoomLevels[zoomIndex] * 100)),
  );
  setDisabledState(zoomOutButtons, zoomIndex === 0);
  setDisabledState(zoomInButtons, zoomIndex === zoomLevels.length - 1);
}

function changeZoom(delta) {
  const nextZoomIndex = clamp(zoomIndex + delta, 0, zoomLevels.length - 1);

  if (nextZoomIndex === zoomIndex) return;

  hideTileMenu();
  zoomIndex = nextZoomIndex;
  layoutCanvas({ preserveCenter: true });
}

function populateTerrainMenu() {
  for (const [type, spec] of Object.entries(terrain)) {
    const button = document.createElement("button");
    const swatch = document.createElement("span");
    const label = document.createElement("span");

    button.type = "button";
    button.className = "terrain-option";
    button.dataset.terrain = type;
    button.setAttribute("role", "menuitem");
    swatch.className = "terrain-swatch";
    swatch.style.background = spec.top;
    label.textContent = spec.label;
    button.append(swatch, label);
    terrainMenuOptions.append(button);
  }
}

function setTileReadout(cell) {
  const spec = terrain[cell.type];
  const variant = getTerrainVariant(cell.type, ensureCellVariant(cell));
  const variantLabel = getTerrainVariants(cell.type).length > 1 && variant ? variant.label : "";

  setTextContent(hoverReadouts, strings.readouts.tile(cell.x, cell.y, spec.label, variantLabel));
}

function openTileMenu(cell, event) {
  activeCell = cell;
  tileMenuTitle.textContent = strings.readouts.tileMenuTitle(cell.x, cell.y);
  tileMenu.hidden = false;
  updateTerrainMenuSelection(cell.type);
  updateVariantMenu(cell);
  positionTileMenu(event.clientX, event.clientY);
  getSelectedTerrainButton()?.focus({ preventScroll: true });

  draw();
}

function positionTileMenu(clientX, clientY) {
  const viewportRect = viewport.getBoundingClientRect();
  const margin = 8;
  const menuWidth = tileMenu.offsetWidth || 176;
  const menuHeight = tileMenu.offsetHeight || 72;
  const minLeft = viewport.scrollLeft + margin;
  const minTop = viewport.scrollTop + margin;
  const maxLeft = Math.max(
    minLeft,
    viewport.scrollLeft + viewport.clientWidth - menuWidth - margin,
  );
  const maxTop = Math.max(
    minTop,
    viewport.scrollTop + viewport.clientHeight - menuHeight - margin,
  );
  const left = clientX - viewportRect.left + viewport.scrollLeft + 12;
  const top = clientY - viewportRect.top + viewport.scrollTop + 12;

  tileMenu.style.left = `${clamp(left, minLeft, maxLeft)}px`;
  tileMenu.style.top = `${clamp(top, minTop, maxTop)}px`;
}

function hideTileMenu() {
  if (tileMenu.hidden) return;

  tileMenu.hidden = true;
  activeCell = null;
  draw();
}

function updateTerrainMenuSelection(type) {
  for (const button of terrainMenuOptions.querySelectorAll(".terrain-option")) {
    const isSelected = button.dataset.terrain === type;

    button.classList.toggle("is-selected", isSelected);
    button.setAttribute("aria-current", isSelected ? "true" : "false");
  }
}

function updateVariantMenu(cell) {
  const variants = getTerrainVariants(cell.type);

  variantMenuOptions.replaceChildren();
  variantMenu.hidden = variants.length <= 1;

  if (variantMenu.hidden) return;

  const selectedVariant = ensureCellVariant(cell);

  for (const variant of variants) {
    const button = document.createElement("button");
    const swatch = document.createElement("span");
    const label = document.createElement("span");
    const isSelected = variant.id === selectedVariant;

    button.type = "button";
    button.className = "terrain-option";
    button.classList.toggle("is-selected", isSelected);
    button.dataset.variant = variant.id;
    button.setAttribute("role", "menuitem");
    button.setAttribute("aria-current", isSelected ? "true" : "false");
    swatch.className = "terrain-swatch";
    swatch.style.background = terrain[cell.type].top;
    label.textContent = variant.label;
    button.append(swatch, label);
    variantMenuOptions.append(button);
  }
}

function getSelectedTerrainButton() {
  return terrainMenuOptions.querySelector(".terrain-option.is-selected");
}

function handleEditCanvasMove(event) {
  const nextHover = pickTile(event.clientX, event.clientY);
  const changed =
    (!hoverCell && nextHover) ||
    (hoverCell && !nextHover) ||
    (hoverCell &&
      nextHover &&
      (hoverCell.x !== nextHover.x || hoverCell.y !== nextHover.y));

  if (!changed) return;

  hoverCell = nextHover;

  if (hoverCell) {
    setTileReadout(hoverCell);
  } else {
    resetTileReadout();
  }

  draw();
}

function handleEditCanvasClick(event, clickedCell) {
  if (!clickedCell) {
    hideTileMenu();
    return;
  }

  hoverCell = clickedCell;
  setTileReadout(clickedCell);
  openTileMenu(clickedCell, event);
}

function handleEditCanvasLeave() {
  hoverCell = null;

  if (activeCell) {
    setTileReadout(activeCell);
  } else {
    resetTileReadout();
  }

  draw();
}

canvas.addEventListener("mousemove", (event) => {
  if (!isEditMode()) return;

  handleEditCanvasMove(event);
});

canvas.addEventListener("click", (event) => {
  const clickedCell = pickTile(event.clientX, event.clientY);

  if (isPlayMode()) {
    handlePlayModeClick(clickedCell);
    return;
  }

  if (!isEditMode()) return;

  handleEditCanvasClick(event, clickedCell);
});

canvas.addEventListener("mouseleave", () => {
  if (!isEditMode()) return;

  handleEditCanvasLeave();
});

function applyTerrainSelection(type) {
  if (!activeCell) return;

  setCellTerrain(activeCell, type);
  setTileReadout(activeCell);
  hideTileMenu();
}

terrainMenuOptions.addEventListener("click", (event) => {
  const button = event.target.closest(".terrain-option");

  if (!button) return;

  applyTerrainSelection(button.dataset.terrain);
});

variantMenuOptions.addEventListener("click", (event) => {
  const button = event.target.closest(".terrain-option");

  if (!button || !activeCell) return;

  activeCell.variant = button.dataset.variant;
  invalidateStaticLayer();
  setTileReadout(activeCell);
  hideTileMenu();
});

document.addEventListener("pointerdown", (event) => {
  if (
    saveSlotOverlay &&
    !saveSlotOverlay.hidden &&
    !saveSlotPanel.contains(event.target)
  ) {
    closeSaveSlotPanel();
    return;
  }

  if (
    gameActionMenu &&
    !gameActionMenu.hidden &&
    !gameActionMenu.contains(event.target) &&
    !gameMenuToggleButtons.some((button) => button.contains(event.target))
  ) {
    closeGameActionMenu();
  }

  if (tileMenu.hidden || tileMenu.contains(event.target) || event.target === canvas) {
    return;
  }

  hideTileMenu();
});

document.addEventListener("keydown", (event) => {
  if (event.key !== "Escape") return;

  if (saveSlotOverlay && !saveSlotOverlay.hidden) {
    closeSaveSlotPanel({ restoreFocus: true });
    return;
  }

  if (gameActionMenu && !gameActionMenu.hidden) {
    closeGameActionMenu({ restoreFocus: true });
    return;
  }

  if (mainMenuOpen) return;

  if (!tileMenu.hidden) {
    hideTileMenu();
    return;
  }

  if (interactionMode === interactionModes.play && getSelectedUnit()) {
    clearUnitSelection();
    draw();
    return;
  }

  openMainMenu();
});

mainMenuOverlay.addEventListener("click", (event) => {
  const button = event.target.closest(".main-menu-item");

  if (!button || button.disabled) return;

  const action = button.dataset.menuAction;

  if (action === "play") {
    activateMode(interactionModes.play);
    return;
  }

  if (action === "start-new-game") {
    startNewGeneratedState(interactionModes.play);
    return;
  }

  if (action === "load-game") {
    loadState(interactionModes.play);
    return;
  }

  if (action === "import-export") {
    openSaveSlotPanel("export", { targetMode: interactionMode || interactionModes.play });
    return;
  }

  if (action === "edit") {
    activateMode(interactionModes.edit);
  }
});

for (const button of gameMenuToggleButtons) {
  button.addEventListener("click", () => {
    toggleGameActionMenu(button);
  });
}

for (const button of newRandomMapButtons) {
  button.addEventListener("click", () => {
    if (!isEditMode()) return;

    closeGameActionMenu();
    startNewGeneratedState(interactionModes.edit, buildGeneratedMapCells);
  });
}

for (const button of newEmptyMapButtons) {
  button.addEventListener("click", () => {
    if (!isEditMode()) return;

    closeGameActionMenu();
    startNewGeneratedState(interactionModes.edit, buildEmptyMapCells);
  });
}

for (const button of nextTurnButtons) {
  button.addEventListener("click", () => {
    advanceTurn();
  });
}

for (const button of unitActionButtons) {
  button.addEventListener("click", () => {
    const selectedUnit = getSelectedUnit();

    if (!selectedUnit || selectedUnit.move) return;
    if (selectedUnit.task && selectedUnit.task.type !== "play") return;

    const action = normalizeUnitAction(button.dataset.unitAction);

    if (action === unitActions.wait) {
      selectNextIdleUnit({
        fromUnit: selectedUnit,
        defaultAction: unitActions.wait,
        scrollIntoView: true,
      });
      return;
    }

    if (action === unitActions.play) {
      queueUnitPlayTask(selectedUnit);
      return;
    }

    selectedUnitAction = action;
    updateUnitActionControls();
    draw();
  });
}

for (const button of loadStateButtons) {
  button.addEventListener("click", () => {
    if (!interactionMode) return;

    closeGameActionMenu();
    loadState(interactionMode);
  });
}

for (const button of saveStateButtons) {
  button.addEventListener("click", () => {
    if (!interactionMode) return;

    closeGameActionMenu();
    saveState(interactionMode);
  });
}

for (const button of saveStateAsButtons) {
  button.addEventListener("click", () => {
    if (!interactionMode) return;

    closeGameActionMenu();
    saveStateAs(interactionMode);
  });
}

for (const button of openMainMenuButtons) {
  button.addEventListener("click", () => {
    openMainMenu();
  });
}

for (const button of dismissSlotPanelButtons) {
  button.addEventListener("click", () => {
    closeSaveSlotPanel({ restoreFocus: true });
  });
}

for (const button of confirmSlotPanelButtons) {
  button.addEventListener("click", () => {
    void commitSaveSlotPanel();
  });
}

for (const button of importSlotPanelButtons) {
  button.addEventListener("click", () => {
    void importSaveIntoSlot(saveSlotInput?.value || slotPanelState?.value || "");
  });
}

saveSlotInput?.addEventListener("input", () => {
  if (!slotPanelState) return;

  slotPanelState.value = sanitizeFileName(saveSlotInput.value);
  renderSaveSlotList();
});

saveSlotInput?.addEventListener("keydown", (event) => {
  if (event.key !== "Enter") return;

  event.preventDefault();
  void commitSaveSlotPanel();
});

saveSlotList?.addEventListener("click", (event) => {
  const button = event.target.closest(".slot-panel-item");

  if (!button || !slotPanelState) return;

  const slotName = button.dataset.slotName || "";
  slotPanelState.value = slotName;
  saveSlotInput.value = slotName;
  renderSaveSlotList();

  if (slotPanelState.mode === "load") {
    void commitSaveSlotPanel();
  }
});

for (const input of autoPassInputs) {
  input.addEventListener("change", (event) => {
    autoAdvanceTurns = event.target.checked;
    updateTurnControls();
    maybeAutoAdvanceTurn();
  });
}

for (const button of zoomOutButtons) {
  button.addEventListener("click", () => {
    changeZoom(-1);
  });
}

for (const button of zoomInButtons) {
  button.addEventListener("click", () => {
    changeZoom(1);
  });
}

window.addEventListener("resize", resizeCanvas);

applyStaticText();
populateTerrainMenu();
void requestPersistentStorage();
applyStateSnapshot(createDefaultState(interactionModes.edit), interactionModes.edit, { recenter: false });
resetTileReadout();
updateInteractionModeUi();
loadTileImages();
resizeCanvas();
